package com.test.todo;

import android.text.format.Time;

public class Task {
    private int todoId ;
    private String task;
    private String description;
    private String dueDate;
    private String dueTime;
    private String address;
    private String done;
    public Task(){
        todoId=-1;
        Time t = new Time();
        t.setToNow();
        dueDate = t.format("yyyy/MM/dd");
        dueTime="12:00";
        done="N";

    }
    public int getTodoID() {
        return todoId;
    }
    public void setTodoID(int i) {
        todoId = i;
    }
    public String getTask() {
        return task;
    }
    public void setTask(String s) {
        task = s;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String s) {
        description = s;
    }
    public String getDueDate() {
        return dueDate;
    }
    public void setDueDate(String s) {
        dueDate = s;
    }
    public String getDueTime() {
        return dueTime;
    }
    public void setDueTime(String s) {
        dueTime = s;
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String s) {
        address = s;
    }
    public String getDone() {
        return done;
    }
    public void setDone(String s) {
        done = s;
    }
}
