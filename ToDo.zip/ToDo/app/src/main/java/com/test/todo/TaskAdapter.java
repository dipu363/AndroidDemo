package com.test.todo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class TaskAdapter extends ArrayAdapter<Task> {
    private ArrayList<Task> items;
    private Context adapterContext;

    public TaskAdapter(Context context, ArrayList<Task> items) {
        super(context, R.layout.list_item, items);
        adapterContext = context;
        this.items = items;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        try {
            Task task = items.get(position);

            if (v == null) {
                LayoutInflater vi = (LayoutInflater) adapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = vi.inflate(R.layout.list_item, null);
            }

            TextView taskName = (TextView) v.findViewById(R.id.textTask);
            TextView description = (TextView) v.findViewById(R.id.textDescription);
            TextView dueDate = (TextView) v.findViewById(R.id.textDueDate);
            TextView dueTime = (TextView) v.findViewById(R.id.textDueTime);
            Button b = (Button) v.findViewById(R.id.buttonDelete);

            taskName.setText(task.getTask());
            description.setText(task.getDescription());
            dueDate.setText(task.getDueDate());
            dueTime.setText(task.getDueTime());
            b.setVisibility(View.INVISIBLE);
        }
        catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
        return v;
    }

    public void showDelete(final int position, final View convertView, final Context context, final Task task) {
        View v = convertView;
        final Button b = (Button) v.findViewById(R.id.buttonDelete);

        if (b.getVisibility()==View.INVISIBLE) {
            b.setVisibility(View.VISIBLE);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    hideDelete(position, convertView, context);
                    items.remove(task);
                    deleteOption(task.getTodoID(), context);
                }

            });
        }
        else {
            hideDelete(position, convertView, context);
        }
    }

    private void deleteOption(int taskToDelete, Context context) {
        DataSource db = new DataSource(context);
        db.open();
        db.deleteTask(taskToDelete);
        db.close();
        this.notifyDataSetChanged();
    }

    private void hideDelete(int position, View convertView, Context context) {
        View v = convertView;
        final Button b = (Button) v.findViewById(R.id.buttonDelete);
        b.setVisibility(View.INVISIBLE);
        b.setOnClickListener(null);
    }

}
