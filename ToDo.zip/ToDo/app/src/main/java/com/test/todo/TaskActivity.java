package com.test.todo;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import java.util.Calendar;
public class TaskActivity extends Activity {
    private Task currentTask;
    private Button todolist;
    private Button donelist;
    private ToggleButton editToggle;
    private Button saveButton;
    private EditText editTask;
    private EditText editDescription;
    private EditText editDueDate ;
    private EditText editDueTime;
    private EditText editAddress;
    private CheckBox chkDone;
    private  Button map;
    int day1;
    int month1;
    int year1;
    static final int DIALOG_ID=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);
        todolist = (Button) findViewById(R.id.buttonToDoList);
        donelist = (Button) findViewById(R.id.buttonDoneList);
        editToggle = (ToggleButton) findViewById(R.id.toggleButtonEdit);
        saveButton = (Button) findViewById(R.id.buttonSave);
        editTask = (EditText) findViewById(R.id.editTask);
        editDescription = (EditText) findViewById(R.id.editDescription);
        editDueDate = (EditText) findViewById(R.id.editDueDate);
        editDueTime= (EditText) findViewById(R.id.editDueTime);
        editAddress= (EditText) findViewById(R.id.editAddress);

        chkDone = (CheckBox) findViewById(R.id.chkDone);
        map = (Button) findViewById(R.id.buttonMap);

        initListButton();
        initDoneListButton();
        initToggleButton();
        initSaveButton();
        initMapButton();

        Bundle extras = getIntent().getExtras();
        if(extras != null) {
            initTask(extras.getInt("taskid"));
        }
        else {
            currentTask = new Task();
        }
        setForEditing(false);

        final Calendar caln= Calendar.getInstance();
        year1= caln.get(Calendar.YEAR);
        month1=caln.get(Calendar.MONTH);
        day1= caln.get(Calendar.DAY_OF_MONTH);
        displayDialog();
        //battery sensor
        BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                double batteryLevel= intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
                double levelScale= intent.getIntExtra(BatteryManager.EXTRA_SCALE,0);
                int batteryPercent = (int) Math.floor(batteryLevel/levelScale*100); //4
                TextView textBatteryState=(TextView)findViewById(R.id.textBatteryLevel);
                textBatteryState.setText(batteryPercent+"%");
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, filter);
        //
    }

    public void displayDialog(){
        editDueDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDialog(DIALOG_ID);
            }
        });
    }

    @Override
    protected Dialog onCreateDialog(int id){

        if (id==DIALOG_ID)
            return new DatePickerDialog(this, dpickerListner, year1, month1, day1);
        return null;
    }

    public DatePickerDialog.OnDateSetListener dpickerListner= new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

            year1=year;
            month1=monthOfYear+1;
            day1=dayOfMonth;

            editDueDate.setText(day1+ "/" +month1 + "/" + year);

        }
    };


    private void initListButton() {
        todolist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(TaskActivity.this, ToDoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("Done","N");
                startActivity(intent);
            }
        });
    }
    private void initDoneListButton() {
        donelist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(TaskActivity.this, ToDoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("Done","Y");
                startActivity(intent);
            }
        });
    }
    private void initToggleButton() {
        editToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                setForEditing(editToggle.isChecked());
            }
        });
    }
    private void initSaveButton() {
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DataSource ds = new DataSource(TaskActivity.this);
                ds.open();
                boolean wasSuccessful = false;
                currentTask.setDescription(editDescription.getText().toString());
                currentTask.setTask(editTask.getText().toString());
                currentTask.setDueDate(editDueDate.getText().toString());
                currentTask.setDueTime(editDueTime.getText().toString());
                currentTask.setAddress(editAddress.getText().toString());
                if (chkDone.isChecked()){
                    currentTask.setDone("Y");
                }
                else
                {
                    currentTask.setDone("N");
                }
                if (currentTask.getTodoID()==-1) {
                    wasSuccessful = ds.insertTask(currentTask);
                    int newId = ds.getLastTodoId();
                    currentTask.setTodoID(newId);
                }
                else {
                    wasSuccessful = ds.updateTask(currentTask);
                }
                ds.close();
                if (wasSuccessful) {
                    editToggle.toggle();
                    setForEditing(false);
                }
            }
        });
    }
    private void setForEditing(boolean enabled) {

        editTask.setEnabled(enabled);
        editDescription.setEnabled(enabled);
        editDueDate.setEnabled(enabled);
        editDueTime.setEnabled(enabled);
        editAddress.setEnabled(enabled);
        chkDone.setEnabled(enabled);
        saveButton.setEnabled(enabled);
        //map.setEnabled(enabled);

        if (enabled) {
            editTask.requestFocus();
        }
        else {
            ScrollView s = (ScrollView) findViewById(R.id.scrollView1);
            s.fullScroll(ScrollView.FOCUS_UP);
            s.clearFocus();
        }

    }
    private void initTask(int id) {

        DataSource ds = new DataSource(TaskActivity.this);

        ds.open();
        currentTask = ds.getSpecificTask(id);
        ds.close();

        editTask.setText(currentTask.getTask());
        editDescription.setText(currentTask.getDescription());
        editDueDate.setText(currentTask.getDueDate());
        editDueTime.setText(currentTask.getDueTime());
        editAddress.setText(currentTask.getAddress());

        if (currentTask.getDone().equals("N")) {
            chkDone.setChecked(false);
        }
        else {
            chkDone.setChecked(true);
        }
    }
    private void initMapButton() {
            map = (Button) findViewById(R.id.buttonMap);
            map.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String s=editAddress.getText().toString();
                    if(s.length()>0)
                    {
                            Intent intent = new Intent(TaskActivity.this, map_activity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            intent.putExtra("address", editAddress.getText().toString());
                            startActivity(intent);
                    }
                    else
                    {
                        Toast.makeText(TaskActivity.this, "no address!!", Toast.LENGTH_LONG).show();
                    }
                }
            });

    }
}
