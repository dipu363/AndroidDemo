package com.test.todo;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
public class map_activity extends AppCompatActivity  implements OnMapReadyCallback{

    String address ;
    List<Address> addresses = new ArrayList<Address>();
    GoogleMap googleMap;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        taskButton();
        SupportMapFragment mapFragment
                = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        Bundle extras = getIntent().getExtras();
        if(extras !=null){
             address = extras.getString("address");
        }
    }

    @Override
    public void onMapReady(GoogleMap gMap) {
        googleMap=gMap;
        UiSettings uiSettings = googleMap.getUiSettings();
        uiSettings.setZoomControlsEnabled(true);
        Geocoder geo = new Geocoder(this);
        try {
              addresses= geo.getFromLocationName(address, 5);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        double lat=addresses.get(0).getLatitude();
        double lng=addresses.get(0).getLongitude();

        LatLng point = new
                LatLng(addresses.get(0).getLatitude(),addresses.get(0).getLongitude());
        googleMap.addMarker(new MarkerOptions().position(point).title(address).snippet(address));
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(point, 18));

    }

    private void taskButton() {
        Button map = (Button) findViewById(R.id.taskButton);
        map.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(map_activity.this, TaskActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }

}



