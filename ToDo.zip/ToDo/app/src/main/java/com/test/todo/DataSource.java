package com.test.todo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
public class DataSource {
    private SQLiteDatabase database;
    private DBHelper dbHelper;

    public DataSource(Context context) {
        dbHelper = new DBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean insertTask(Task c)
    {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("task", c.getTask());
            initialValues.put("description", c.getDescription());
            initialValues.put("dueDate", c.getDueDate());
            initialValues.put("dueTime", c.getDueTime());
            initialValues.put("address", c.getAddress());
            initialValues.put("done", c.getDone());
            didSucceed = database.insert("todo", null, initialValues) > 0;

        }
        catch (Exception e) {
            //Do Nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateTask(Task c)
    {
        boolean didSucceed = false;
        try {
            Long rowId = Long.valueOf(c.getTodoID());
            ContentValues updateValues = new ContentValues();

            updateValues.put("task", c.getTask());
            updateValues.put("description", c.getDescription());
            updateValues.put("dueDate", c.getDueDate());
            updateValues.put("dueTime", c.getDueTime());
            updateValues.put("address", c.getAddress());
            updateValues.put("done", c.getDone());
            didSucceed = database.update("todo", updateValues, "_id=" + rowId, null) > 0;
        }
        catch (Exception e) {
            //Do Nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public int getLastTodoId() {
        int lastId = -1;
        try
        {
            String query = "Select MAX(_id) from todo";
            Cursor cursor = database.rawQuery(query, null);

            cursor.moveToFirst();
            lastId = cursor.getInt(0);
            cursor.close();
        }
        catch (Exception e) {
            lastId = -1;
        }
        return lastId;
    }

    public ArrayList<Task> getTasks(String isDone) {
        ArrayList<Task> todos = new ArrayList<Task>();
        try {
            String query = "SELECT  * FROM todo Where Done ='" + isDone + "' ORDER BY dueDate, dueTime " ;
            Cursor cursor = database.rawQuery(query, null);

            Task newTask;
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                newTask = new Task();
                newTask.setTodoID(cursor.getInt(0));
                newTask.setTask(cursor.getString(1));
                newTask.setDescription(cursor.getString(2));
                newTask.setDueDate(cursor.getString(3));
                newTask.setDueTime(cursor.getString(4));
                newTask.setAddress(cursor.getString(5));
                newTask.setDone(cursor.getString(6));

                todos.add(newTask);
                cursor.moveToNext();

            }
            cursor.close();
        }
        catch (Exception e) {
            todos = new ArrayList<Task>();
        }
        return todos;
    }

    public Task getSpecificTask(int todoId) {
        Task task = new Task();

        String query = "SELECT  * FROM todo WHERE _id =" + todoId;
        Cursor cursor = database.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            task.setTodoID(cursor.getInt(0));
            task.setTask(cursor.getString(1));
            task.setDescription(cursor.getString(2));
            task.setDueDate(cursor.getString(3));
            task.setDueTime(cursor.getString(4));
            task.setAddress(cursor.getString(5));
            task.setDone(cursor.getString(6));
        }
        cursor.close();

        return task;
    }

    public boolean deleteTask(int taskId) {
        boolean didDelete = false;
        try {
            didDelete = database.delete("todo", "_id=" + taskId, null) > 0;
        }
        catch (Exception e) {
            //Do nothing -return value already set to false
        }
        return didDelete;
    }
}
