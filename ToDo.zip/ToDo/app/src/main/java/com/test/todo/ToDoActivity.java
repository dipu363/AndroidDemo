package com.test.todo;

import android.app.Activity;
import android.app.ListActivity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ToDoActivity extends ListActivity {

    boolean isDeleting = false;
    TaskAdapter adapter;
    Button todolist ;
    Button donelist ;
    BroadcastReceiver batteryReceiver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_do);
        todolist = (Button) findViewById(R.id.buttonToDoList);
        donelist = (Button) findViewById(R.id.buttonDoneList);

        //battery sensor
        batteryReceiver  = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                double batteryLevel= intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
                double levelScale= intent.getIntExtra(BatteryManager.EXTRA_SCALE,0);
                int batteryPercent = (int) Math.floor(batteryLevel/levelScale*100); //4
                TextView textBatteryState=(TextView)findViewById(R.id.textBatteryLevel);
                textBatteryState.setText(batteryPercent+"%");
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, filter);

        initListButton();
        initDoneListButton();
        initDeleteButton();
        initAddTaskButton();


    }

    @Override
    public void onResume() {
        super.onResume();
        Bundle extras = getIntent().getExtras();
        String isDone="N";
        if(extras != null) {
            isDone = extras.getString("Done");
        }
        if ( isDone!=null && isDone.equals("Y")) {
            donelist.setEnabled(false);
            todolist.setEnabled(true);
        }
        else{
            isDone = "N";
            donelist.setEnabled(true);
            todolist.setEnabled(false);
        }

        DataSource ds = new DataSource(this);
        ds.open();

        final ArrayList<Task> tasks = ds.getTasks(isDone);
        ds.close();

        if (tasks.size() > 0) {

            adapter = new TaskAdapter(this, tasks);
            setListAdapter(adapter);
            ListView listView = getListView();
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View itemClicked,
                                        int position, long id) {
                    Task selectedTask = tasks.get(position);
                    if (isDeleting) {
                        adapter.showDelete(position, itemClicked, ToDoActivity.this, selectedTask);
                    }
                    else {
                        Intent intent = new Intent(ToDoActivity.this, TaskActivity.class);
                        intent.putExtra("taskid", selectedTask.getTodoID());
                        startActivity(intent);
                    }
                }
            });
        }
        else {
            Button deleteButton = (Button) findViewById(R.id.buttonDelete);
            deleteButton.setEnabled(false);
            Toast.makeText(this, "No tasks  !!", Toast.LENGTH_LONG).show();
        }
    }
    private void initAddTaskButton() {
        Button newTask = (Button) findViewById(R.id.buttonAdd);
        newTask.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ToDoActivity.this, TaskActivity.class);
                startActivity(intent);
            }
        });
    }
    private void initDeleteButton() {
        final Button deleteButton = (Button) findViewById(R.id.buttonDelete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (isDeleting) {
                    deleteButton.setText("Delete");
                    isDeleting = false;

                    adapter.notifyDataSetChanged();
                }
                else {
                    deleteButton.setText("Done Deleting");
                    isDeleting = true;
                }
            }
        });
    }
    private void initListButton() {

        todolist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ToDoActivity.this, ToDoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("Done","N");
                startActivity(intent);
            }
        });
    }
    private void initDoneListButton() {

        donelist.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ToDoActivity.this, ToDoActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("Done","Y");
                startActivity(intent);
            }
        });
    }


    @Override
    protected void onPause() {
        unregisterReceiver(batteryReceiver);
        super.onPause();
    }
}
