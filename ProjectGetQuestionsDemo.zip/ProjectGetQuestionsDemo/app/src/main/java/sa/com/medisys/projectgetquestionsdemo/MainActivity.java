package sa.com.medisys.projectgetquestionsdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;


import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {



    List<Question> questionManilist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionManilist = new ArrayList<>();

        getAllQuestion("1","00000054","1");

    }


    public void getAllQuestion(String gen, String patno, String lang) {

        // sqLiteDB.deleteAll();//delete all existing raw first then inserted new raw

ApiService apiService = ApiClient.getRetrofit().create(ApiService.class);
        Call<QuestionariRespons> call = apiService.getallquestions(gen,patno,lang);
        call.enqueue(new Callback<QuestionariRespons>() {
            @Override
            public void onResponse(Call<QuestionariRespons> call, Response<QuestionariRespons> response) {
                QuestionariRespons questionariRespons = response.body();
                assert questionariRespons != null;
                questionManilist = questionariRespons.getData();

                Log.d("onResponse",""+questionManilist.size());
            }

            @Override
            public void onFailure(Call<QuestionariRespons> call, Throwable t) {
                Log.d("onFailure","field"+t.getMessage());

            }
        });



    }
}