package sa.com.medisys.projectgetquestionsdemo;

import java.util.List;



public class QuestionariRespons {
/*    total	42
    data	[…]
    success	true
    message	"Question info."*/

    private int total;
   List<Question> data;
   private boolean success;
   private String message;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<Question> getData() {
        return data;
    }

    public void setData(List<Question> data) {
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
