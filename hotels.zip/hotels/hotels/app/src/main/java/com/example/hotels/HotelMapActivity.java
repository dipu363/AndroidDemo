package com.example.hotels;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Point;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.View;

import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class HotelMapActivity extends AppCompatActivity implements OnMapReadyCallback {

    GoogleMap googleMap;
    ArrayList<Hotel> hotels = new ArrayList<Hotel>();
    List<Address> addresses = new ArrayList<Address>();
    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;
        googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        if (addresses !=null && !addresses.isEmpty()) {
            for(int i=0;i<addresses.size();i++) {
                LatLng point = new LatLng(addresses.get(i).getLatitude(), addresses.get(i).getLongitude());
                googleMap.addMarker(new MarkerOptions().position(point).title(hotels.get(0).getHotelName()));
            }
            try
            {
                LatLng ASH = new LatLng(22, 56);
                LatLng TABOUK = new LatLng(21, 53);
                LatLngBounds SA = new LatLngBounds(TABOUK,ASH);
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(SA.getCenter(),4));
            }
            catch(Exception e){}
        }
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_map);
        initListButton();
        initMapButton();
        SupportMapFragment googleMap = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        googleMap.getMapAsync(this);

        Hotel currentHotel = null;
        HotelDataSource ds = new HotelDataSource(HotelMapActivity.this);
        ds.open();
        hotels = ds.getHotels();
        ds.close();
        if (hotels.size()>0) {
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            for (int i=0; i<hotels.size(); i++) {
                currentHotel = hotels.get(i);
                Geocoder geo = new Geocoder(this);
                String address = currentHotel.getStreetAddress() + ", " +
                        currentHotel.getCity() + ", " +
                        currentHotel.getState() + " " +
                        currentHotel.getZipCode();
                try {
                    List<Address> abc= geo.getFromLocationName(address, 1);
                    if (abc !=null && abc.size()>0){
                    addresses.add(abc.get(0));}
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        else {
            if (currentHotel != null) {
                Geocoder geo = new Geocoder(this);
                String address = currentHotel.getStreetAddress() + ", " +
                        currentHotel.getCity() + ", " +
                        currentHotel.getState() + " " +
                        currentHotel.getZipCode();
                try {
                    addresses = geo.getFromLocationName(address, 1);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
            else {
                AlertDialog alertDialog = new AlertDialog.Builder(HotelMapActivity.this).create();
                alertDialog.setTitle("No Data");
                alertDialog.setMessage("No data is available for the mapping function.");
                alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    } });
                alertDialog.show();
            }
        }
    }
    public void onPause() {
        super.onPause();
        finish();
    }
    @Override
    public void onResume() {
        super.onResume();
        final String TAG_ERROR_DIALOG_FRAGMENT="errorDialog";
        int status= GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
        if (status == ConnectionResult.SUCCESS) {
            //no problems just work
        }
        else if (GooglePlayServicesUtil.isUserRecoverableError(status)) {
            //ErrorDialogFragment.newInstance(status).show(getSupportFragmentManager(), TAG_ERROR_DIALOG_FRAGMENT);
        }
        else {
            Toast.makeText(this, "Google Maps V2 is not available!", Toast.LENGTH_LONG).show();
            finish();
        }
    }
    private void initListButton() {
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonList);
        list.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(HotelMapActivity.this, HotelList.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initMapButton() {
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonMap);
        list.setEnabled(false);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        return true;
    }
}
