package com.example.hotels;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;


public class HotelDataSource {

    private SQLiteDatabase database;
    private HotelDBHelper dbHelper;

    public HotelDataSource(Context context) {
        dbHelper = new HotelDBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public boolean insertHotel(Hotel h)
    {
        boolean didSucceed = false;
        try {
            ContentValues initialValues = new ContentValues();

            initialValues.put("hotelname", h.getHotelName());
            initialValues.put("streetaddress", h.getStreetAddress());
            initialValues.put("city", h.getCity());
            initialValues.put("state", h.getState());
            initialValues.put("zipcode", h.getZipCode());
            initialValues.put("phonenumber", h.getPhoneNumber());
            initialValues.put("email", h.getEMail());

            didSucceed = database.insert("hotel", null, initialValues) > 0;

        }
        catch (Exception e) {
            //Do Nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public boolean updateHotel(Hotel h)
    {
        boolean didSucceed = false;
        try {
            Long rowId = Long.valueOf(h.getHotelID());
            ContentValues updateValues = new ContentValues();

            updateValues.put("hotelname", h.getHotelName());
            updateValues.put("streetaddress", h.getStreetAddress());
            updateValues.put("city", h.getCity());
            updateValues.put("state", h.getState());
            updateValues.put("zipcode", h.getZipCode());
            updateValues.put("phonenumber", h.getPhoneNumber());
            updateValues.put("email", h.getEMail());

            didSucceed = database.update("hotel", updateValues, "_id=" + rowId, null) > 0;
        }
        catch (Exception e) {
            //Do Nothing -will return false if there is an exception
        }
        return didSucceed;
    }

    public int getLastHotelId() {
        int lastId = -1;
        try
        {
            String query = "Select MAX(_id) from hotel";
            Cursor cursor = database.rawQuery(query, null);

            cursor.moveToFirst();
            lastId = cursor.getInt(0);
            cursor.close();
        }
        catch (Exception e) {
            lastId = -1;
        }
        return lastId;
    }

    public ArrayList<String> getHotelName() {
        ArrayList<String> hotelNames = new ArrayList<String>();
        try {
            String query = "Select hotelname from hotel";
            Cursor cursor = database.rawQuery(query, null);

            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {

                hotelNames.add(cursor.getString(0));
                cursor.moveToNext();
            }
            cursor.close();
        }
        catch (Exception e) {
            hotelNames = new ArrayList<String>();
        }
        return hotelNames;
    }

    public ArrayList<Hotel> getHotels() {
        ArrayList<Hotel> hotels = new ArrayList<Hotel>();
        try {
            String query = "SELECT  * FROM hotel " ;
            Cursor cursor = database.rawQuery(query, null);

            Hotel newHotel;
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                newHotel = new Hotel();
                newHotel.setHotelID(cursor.getInt(0));
                newHotel.setHotelName(cursor.getString(1));
                newHotel.setStreetAddress(cursor.getString(2));
                newHotel.setCity(cursor.getString(3));
                newHotel.setState(cursor.getString(4));
                newHotel.setZipCode(cursor.getString(5));
                newHotel.setPhoneNumber(cursor.getString(6));
                newHotel.setEMail(cursor.getString(7));
                hotels.add(newHotel);
                cursor.moveToNext();
            }
            cursor.close();
        }
        catch (Exception e) {
            hotels = new ArrayList<Hotel>();
        }
        return hotels;
    }
    public Hotel getSpecificHotel(int hotelId) {
        Hotel hotel = new Hotel();
        String query = "SELECT  * FROM hotel WHERE _id =" + hotelId;
        Cursor cursor = database.rawQuery(query, null);
        if (cursor.moveToFirst()) {
            hotel.setHotelID(cursor.getInt(0));
            hotel.setHotelName(cursor.getString(1));
            hotel.setStreetAddress(cursor.getString(2));
            hotel.setCity(cursor.getString(3));
            hotel.setState(cursor.getString(4));
            hotel.setZipCode(cursor.getString(5));
            hotel.setPhoneNumber(cursor.getString(6));
            hotel.setEMail(cursor.getString(7));
        }
        cursor.close();

        return hotel;
    }
    public boolean deleteHotel( int hotelId) {
        boolean didDelete = false ;
        try {
            didDelete = database.delete( "hotel" , "_id=" + hotelId, null ) > 0;
        }
        catch (Exception e) {
//Do nothing -return value already set to false
        }
        return didDelete;
    }
}
