package com.example.hotels;

import android.text.format.Time;


public class Hotel {
    private int HotelID;
    private String hotelName;
    private String streetAddress;
    private String city;
    private String state;
    private String zipCode;
    private String phoneNumber;
    private String eMail;

    public Hotel() {
        HotelID = -1;
    }

    public int getHotelID() {
        return HotelID;
    }
    public void setHotelID(int i) {
        HotelID = i;
    }
    public String getHotelName() {
        return hotelName;
    }
    public void setHotelName(String s) {
        hotelName = s;
    }
    public String getStreetAddress() {
        return streetAddress;
    }
    public void setStreetAddress(String s) {
        streetAddress = s;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String s) {
        city = s;
    }
    public String getState() {
        return state;
    }
    public void setState(String s) {
        state = s;
    }
    public String getZipCode() {
        return zipCode;
    }
    public void setZipCode(String s) {
        zipCode = s;
    }
    public void setPhoneNumber(String s) {
        phoneNumber = s;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setEMail(String s) {
        eMail = s;
    }
    public String getEMail() {
        return eMail;
    }
}
