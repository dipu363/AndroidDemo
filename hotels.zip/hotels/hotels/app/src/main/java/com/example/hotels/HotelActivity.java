package com.example.hotels;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.text.format.Time;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ToggleButton;

public class HotelActivity extends AppCompatActivity {

    EditText editName;
    EditText editAddress;
    EditText editCity ;
    EditText editState;
    EditText editZipCode;
    EditText editPhone;
    EditText editEmail;
    Button buttonSave ;
    private ToggleButton editToggle;
    private Hotel currentHotel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel);

        editName = (EditText) findViewById(R.id.editName);
        editAddress = (EditText) findViewById(R.id.editAddress);
        editCity = (EditText) findViewById(R.id.editCity);
        editState = (EditText) findViewById(R.id.editState);
        editZipCode = (EditText) findViewById(R.id.editZipcode);
        editPhone = (EditText) findViewById(R.id.editHome);
        editEmail = (EditText) findViewById(R.id.editEMail);
        buttonSave = (Button) findViewById(R.id.buttonSave);
        editToggle = (ToggleButton) findViewById(R.id.toggleButtonEdit);
        initListButton();
        initMapButton();
        initSave();
        initToggleButton();
        Bundle extras = getIntent().getExtras();
        if(extras != null) {
            initHotel(extras.getInt("hotelid"));
            setForEdit(false);
        }
        else {
            currentHotel = new Hotel();
            setForEdit(true);
        }

        BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                double batteryLevel= intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
                double levelScale= intent.getIntExtra(BatteryManager.EXTRA_SCALE,0);
                int batteryPercent = (int) Math.floor(batteryLevel/levelScale*100);
                TextView textBatteryState=(TextView)findViewById(R.id.textBatteryLevel);
                textBatteryState.setText(batteryPercent+"%");
            }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, filter);
    }
    private void initSave(){
        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText streetAddress = (EditText) findViewById(R.id.editAddress);
                EditText hotelName = (EditText) findViewById(R.id.editName);
                EditText city = (EditText) findViewById(R.id.editCity);
                EditText state = (EditText) findViewById(R.id.editState);
                EditText zipcode = (EditText) findViewById(R.id.editZipcode);
                EditText phoneNumber = (EditText) findViewById(R.id.editHome);
                EditText eMail = (EditText) findViewById(R.id.editEMail);
                currentHotel.setHotelName(hotelName.getText().toString());
                currentHotel.setStreetAddress(streetAddress.getText().toString());
                currentHotel.setCity(city.getText().toString());
                currentHotel.setState(state.getText().toString());
                currentHotel.setZipCode(zipcode.getText().toString());
                currentHotel.setPhoneNumber(phoneNumber.getText().toString());
                currentHotel.setEMail(eMail.getText().toString());

                HotelDataSource ds = new HotelDataSource(HotelActivity.this);
                ds.open();

                boolean wasSuccessful = false;
                if (currentHotel.getHotelID()==-1) {
                    wasSuccessful = ds.insertHotel(currentHotel);
                    int newId = ds.getLastHotelId();
                    currentHotel.setHotelID(newId);
                }
                else {
                    wasSuccessful = ds.updateHotel(currentHotel);
                }
                ds.close();

                if (wasSuccessful) {
                    Intent intent = new Intent(HotelActivity.this, HotelList.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }
        });
    }
    private void initListButton(){
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonList);
        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HotelActivity.this, HotelList.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initMapButton(){
        ImageButton map = (ImageButton) findViewById(R.id.imageButtonMap);
        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HotelActivity.this, HotelMapActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
    private void initHotel(int id) {

        HotelDataSource ds = new HotelDataSource(HotelActivity.this);
        ds.open();
        currentHotel = ds.getSpecificHotel(id);
        ds.close();

        editName.setText(currentHotel.getHotelName());
        editAddress.setText(currentHotel.getStreetAddress());
        editCity.setText(currentHotel.getCity());
        editState.setText(currentHotel.getState());
        editZipCode.setText(currentHotel.getZipCode());
        editPhone.setText(currentHotel.getPhoneNumber());
        editEmail.setText(currentHotel.getEMail());
    }
    private void setForEdit(boolean b){

        editName.setEnabled(b);
        editAddress.setEnabled(b);
        editCity.setEnabled(b);
        editState.setEnabled(b);
        editZipCode.setEnabled(b);
        editPhone.setEnabled(b);
        editEmail.setEnabled(b);
        buttonSave.setEnabled(b);
        if (b) {
            editName.requestFocus();
        }
        else {
            ScrollView s = (ScrollView) findViewById(R.id.scrollView1);
            s.fullScroll(ScrollView.FOCUS_UP);
            s.clearFocus();
        }

    }
    private void initToggleButton() {
        editToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                setForEdit(editToggle.isChecked());
            }
        });
    }
}
