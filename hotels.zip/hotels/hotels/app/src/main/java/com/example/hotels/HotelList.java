package com.example.hotels;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import java.util.ArrayList;

public class HotelList extends ListActivity {

    HotelAdapter adapter;
    boolean isDeleting = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_list);
        initDeleteButton();
        initAddButton();
        initListButton();
        initMapButton();
    }

    @Override
    public void onResume() {
        super.onResume();
        HotelDataSource ds = new HotelDataSource(this);
        ds.open();
        final ArrayList<Hotel> hotels = ds.getHotels();
        ds.close();

        if (hotels.size() > 0) {
            adapter = new HotelAdapter(this, hotels);
            setListAdapter(adapter);
            ListView listView = getListView();
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View itemClicked, int position, long id) {
                    Hotel selectedHotel = hotels.get(position);
                    if (isDeleting) {
                        adapter.showDelete(position, itemClicked, HotelList.this, selectedHotel);
                    }
                    else {
                        Intent intent = new Intent(HotelList.this, HotelActivity.class);
                        intent.putExtra("hotelid", selectedHotel.getHotelID());
                        startActivity(intent);
                    }
                }
            });
        }
        else {
            Intent intent = new Intent(HotelList.this, HotelActivity.class);
            startActivity(intent);
        }
    }

    private void initAddButton() {
        Button newHotel = (Button) findViewById(R.id.buttonAdd);
        newHotel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(HotelList.this, HotelActivity.class);
                startActivity(intent);
            }
        });
    }
    private void initDeleteButton() {
        final Button deleteButton = (Button) findViewById(R.id.buttonDelete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (isDeleting) {
                    deleteButton.setText("Delete");
                    isDeleting = false;
                    adapter.notifyDataSetChanged();
                }
                else {
                    deleteButton.setText("Done Deleting");
                    isDeleting = true;
                }
            }
        });
    }
    private void initListButton() {
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonList);
        list.setEnabled(false);
    }
    private void initMapButton() {
        ImageButton list = (ImageButton) findViewById(R.id.imageButtonMap);
        list.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(HotelList.this, HotelMapActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
    }
}
