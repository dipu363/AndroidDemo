package com.example.hotels;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;



public class HotelAdapter extends ArrayAdapter<Hotel> {

    private ArrayList<Hotel> items;
    private Context adapterContext;

    public HotelAdapter(Context context, ArrayList<Hotel> items) {
        super(context, R.layout.list_item, items);
        adapterContext = context;
        this.items = items;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        try {
            Hotel hotel = items.get(position);
            if (v == null ) {
                LayoutInflater vi = (LayoutInflater) adapterContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE );
                v = vi.inflate(R.layout.list_item , null );
            }
            TextView hotelName = (TextView) v.findViewById(R.id.textHotelName );
            TextView hotelNumber = (TextView) v.findViewById(R.id.textPhoneNumber );
            Button b = (Button) v.findViewById(R.id.buttonDeleteHotel );
            hotelName.setText(hotel.getHotelName());
            hotelNumber.setText(hotel.getPhoneNumber());
            b.setVisibility(View.INVISIBLE );
        }
        catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
        return v;
    }

    public void showDelete(final int position, final View convertView, final Context context, final Hotel hotel) {
        View v = convertView;
        final Button b = (Button) v.findViewById(R.id.buttonDeleteHotel);

        if (b.getVisibility()==View.INVISIBLE) {
            b.setVisibility(View.VISIBLE);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    hideDelete(position, convertView, context);
                    items.remove(hotel);
                    deleteOption(hotel.getHotelID(), context);
                }
            });
        }
        else {
            hideDelete(position, convertView, context);
        }
    }
    private void deleteOption(int hotelToDelete, Context context) {
        HotelDataSource db = new HotelDataSource(context);
        db.open();
        db.deleteHotel(hotelToDelete);
        db.close();
        this.notifyDataSetChanged();
    }
    private void hideDelete(int position, View convertView, Context context) {
        View v = convertView;
        final Button b = (Button) v.findViewById(R.id.buttonDeleteHotel);
        b.setVisibility(View.INVISIBLE);
        b.setOnClickListener(null);
    }
}
