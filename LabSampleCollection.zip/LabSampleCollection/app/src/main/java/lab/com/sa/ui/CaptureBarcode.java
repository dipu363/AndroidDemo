package lab.com.sa.ui;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureBarcode extends CaptureActivity {
}
