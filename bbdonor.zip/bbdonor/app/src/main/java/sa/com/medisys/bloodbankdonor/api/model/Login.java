package sa.com.medisys.bloodbankdonor.api.model;

/*
 @author : Md. Abu Bakar Siddique
 @date : 20-AUG-2019
 @version: 1.0.0
*/

import java.io.Serializable;

public class Login implements Serializable {

    private String T_LOGIN_NAME;
    private String T_USER_NAME;
    private String T_PWD;
    private String T_SITE_CODE;
    private String T_EMP_CODE;
    private String T_ROLE_CODE;
    private String T_USER_LANG;
    private String SITE_NATIVE;
    private String SITE_GLOBAL;

    public String getT_LOGIN_NAME() {
        return T_LOGIN_NAME;
    }

    public void setT_LOGIN_NAME(String t_LOGIN_NAME) {
        T_LOGIN_NAME = t_LOGIN_NAME;
    }

    public String getT_USER_NAME() {
        return T_USER_NAME;
    }

    public void setT_USER_NAME(String t_USER_NAME) {
        T_USER_NAME = t_USER_NAME;
    }

    public String getT_PWD() {
        return T_PWD;
    }

    public void setT_PWD(String t_PWD) {
        T_PWD = t_PWD;
    }

    public String getT_SITE_CODE() {
        return T_SITE_CODE;
    }

    public void setT_SITE_CODE(String t_SITE_CODE) {
        T_SITE_CODE = t_SITE_CODE;
    }

    public String getT_EMP_CODE() {
        return T_EMP_CODE;
    }

    public void setT_EMP_CODE(String t_EMP_CODE) {
        T_EMP_CODE = t_EMP_CODE;
    }

    public String getT_ROLE_CODE() {
        return T_ROLE_CODE;
    }

    public void setT_ROLE_CODE(String t_ROLE_CODE) {
        T_ROLE_CODE = t_ROLE_CODE;
    }

    public String getT_USER_LANG() {
        return T_USER_LANG;
    }

    public void setT_USER_LANG(String t_USER_LANG) {
        T_USER_LANG = t_USER_LANG;
    }

    public String getSITE_NATIVE() {
        return SITE_NATIVE;
    }

    public void setSITE_NATIVE(String SITE_NATIVE) {
        this.SITE_NATIVE = SITE_NATIVE;
    }

    public String getSITE_GLOBAL() {
        return SITE_GLOBAL;
    }

    public void setSITE_GLOBAL(String SITE_GLOBAL) {
        this.SITE_GLOBAL = SITE_GLOBAL;
    }
}
