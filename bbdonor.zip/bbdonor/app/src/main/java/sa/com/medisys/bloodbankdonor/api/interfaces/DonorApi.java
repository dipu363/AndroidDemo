package sa.com.medisys.bloodbankdonor.api.interfaces;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
import sa.com.medisys.bloodbankdonor.api.collection.DonorCollection;
import sa.com.medisys.bloodbankdonor.api.collection.LabelCollection;
import sa.com.medisys.bloodbankdonor.api.collection.LoginCollection;
import sa.com.medisys.bloodbankdonor.api.collection.QuestionCollection;

public interface DonorApi {

    /***************** << LABEL >> *****************/
    /*GetLabelText*/
    @GET("GetLabelText")
    Call<LabelCollection> getLoginLabels(@Query("formcode") String form);

    @GET("CheckLogin")
    Call<LoginCollection> login(@Query("loginName") String usernae, @Query("password") String pass);

    @GET("GetDonorInfo")
    Call<DonorCollection> getDonorInfo(@Query("patNo") String patNo, @Query("siteCode") String siteCode);

    @GET("GetQuestionList")
    Call<QuestionCollection> getQuestionList(@Query("gender") String sex, @Query("patNo") String patNo, @Query("lang") String lang);

}
