package sa.com.medisys.bloodbankdonor.database.service;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import sa.com.medisys.bloodbankdonor.api.model.Question;
import sa.com.medisys.bloodbankdonor.database.AppDatabaseSchema;
import sa.com.medisys.bloodbankdonor.database.entity.QuestionEntity;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;

/*
 @author : Md. Abu Bakar Siddique
 @date : 27-OCT-2021
 @version: 1.0.0
*/

public class QuestionService extends AppDatabaseSchema {
    private final String TAG = this.getClass().getSimpleName();

    public QuestionService(Context context) {
        super(context);
    }

    public boolean insertQuestion(List<Question> list) {
        SQLiteDatabase db = null;
        SQLiteStatement stmt = null;
        boolean check = false;
        try {
            db = this.getWritableDatabase();
            db.beginTransactionNonExclusive();

            String sql = "INSERT INTO " + TABLE_QUESTION + " ( "
                    + MROW + " , " + QuestionEntity.HEADER_NO+ " , "
                    + QuestionEntity.TOTAL_QUES+ " , "
                    + QuestionEntity.QUES_NATIVE+ " , "
                    + QuestionEntity.QUES_ENGLISH+ " , "
                    + QuestionEntity.T_QHEAD_NO+ " , "
                    + QuestionEntity.HEADER_NATIVE+ " , "
                    + QuestionEntity.HEADER_ENGLISH+ " , "
                    + QuestionEntity.T_QNO+ " , "
                    + QuestionEntity.T_DISP_SEQ+ " , "
                    + QuestionEntity.T_DIFFERAL_DAY+ " , "
                    + QuestionEntity.T_EXP_ANS+ " , "
                    + QuestionEntity.T_QNO_ANS+ " , "
                    + QuestionEntity.T_QUES_ID+ " , "
                    + QuestionEntity.T_IF_FAIL
                    + " ) VALUES (  "
                    + " ?,?,?,?,?,?,?,?,?,?,?,?,?,?,? "
                    +")";

            stmt = db.compileStatement(sql);
            for(Question obj : list){
                stmt.bindString(1, obj.getR() == null?"":obj.getR());
                stmt.bindString(2, obj.getHEADER_NO()== null?"":obj.getHEADER_NO());
                stmt.bindString(3, obj.getTOTAL_QUES() == null?"":obj.getTOTAL_QUES());
                stmt.bindString(4, obj.getQUES_NATIVE() == null?"":obj.getQUES_NATIVE());
                stmt.bindString(5, obj.getQUES_ENGLISH() == null?"":obj.getQUES_ENGLISH());
                stmt.bindString(6, obj.getT_QHEAD_NO() == null?"":obj.getT_QHEAD_NO());
                stmt.bindString(7, obj.getHEADER_NATIVE() == null?"":obj.getHEADER_NATIVE());
                stmt.bindString(8, obj.getHEADER_ENGLISH() == null?"":obj.getHEADER_ENGLISH());
                stmt.bindString(9, obj.getT_QNO() == null?"":obj.getT_QNO());
                stmt.bindString(10, obj.getT_DISP_SEQ() == null?"":obj.getT_DISP_SEQ());
                stmt.bindString(11, obj.getT_DIFFERAL_DAY() == null?"":obj.getT_DIFFERAL_DAY());
                stmt.bindString(12, obj.getT_EXP_ANS() == null?"":obj.getT_EXP_ANS());
                stmt.bindString(13, obj.getT_QNO_ANS() == null?"":obj.getT_QNO_ANS());
                stmt.bindString(14, obj.getT_QUES_ID() == null?"":obj.getT_QUES_ID());
                stmt.bindString(15, obj.getT_IF_FAIL() == null?"":obj.getT_IF_FAIL());
                stmt.execute();
                stmt.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
            Log.i(TAG, "Question insert successfully");
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, stmt, null);
            return check;
        }
    }

    public ArrayList<Question> getQuestion() {
        SQLiteDatabase db = null;
        Cursor res = null;
        ArrayList<Question> list = new ArrayList<>();
        try {
            list = new ArrayList<>();
            db = this.getReadableDatabase();
            String query = "SELECT "
                    + QuestionEntity.HEADER_NO + " , " + QuestionEntity.TOTAL_QUES+ " , "
                    + QuestionEntity.QUES_NATIVE + " , " + QuestionEntity.QUES_ENGLISH+ " , "
                    + QuestionEntity.T_QHEAD_NO + " , " + QuestionEntity.HEADER_NATIVE+ " , "
                    + QuestionEntity.HEADER_ENGLISH + " , " + QuestionEntity.T_QNO+ " , "
                    + QuestionEntity.T_DISP_SEQ + " , " + QuestionEntity.T_DIFFERAL_DAY+ " , "
                    + QuestionEntity.T_EXP_ANS + " , " + QuestionEntity.T_QNO_ANS+ " , "
                    + QuestionEntity.T_QUES_ID + " , " + QuestionEntity.T_IF_FAIL+ " , "
                    + MROW
                    + " FROM " + TABLE_QUESTION;

            res = db.rawQuery(query, null);
            res.moveToFirst();
            while (res.isAfterLast() == false) {
                Question obj = new Question();
                obj.setR(res.getString(res.getColumnIndexOrThrow(MROW)));
                obj.setHEADER_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NO)));
                obj.setTOTAL_QUES(res.getString(res.getColumnIndexOrThrow(QuestionEntity.TOTAL_QUES)));
                obj.setQUES_NATIVE(res.getString(res.getColumnIndexOrThrow(QuestionEntity.QUES_NATIVE)));
                obj.setQUES_ENGLISH(res.getString(res.getColumnIndexOrThrow(QuestionEntity.QUES_ENGLISH)));
                obj.setT_QHEAD_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QHEAD_NO)));
                obj.setHEADER_NATIVE(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NATIVE)));
                obj.setHEADER_ENGLISH(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_ENGLISH)));
                obj.setT_QNO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QNO)));
                obj.setT_DISP_SEQ(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_DISP_SEQ)));
                obj.setT_DIFFERAL_DAY(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_DIFFERAL_DAY)));
                obj.setT_EXP_ANS(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_EXP_ANS)));
                obj.setT_QNO_ANS(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QNO_ANS)));
                obj.setT_QUES_ID(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QUES_ID)));
                obj.setT_IF_FAIL(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_IF_FAIL)));
                list.add(obj);
                res.moveToNext();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, res);
            return list;
        }
    }

    public ArrayList<Question> getQuestionsByHeaderNo(String code) {
        SQLiteDatabase db = null;
        Cursor res = null;
        ArrayList<Question> list = new ArrayList<>();
        try {
            db = this.getReadableDatabase();
            String query = "SELECT "
                    + QuestionEntity.HEADER_NO + " , " + QuestionEntity.TOTAL_QUES+ " , "
                    + QuestionEntity.QUES_NATIVE + " , " + QuestionEntity.QUES_ENGLISH+ " , "
                    + QuestionEntity.T_QHEAD_NO + " , " + QuestionEntity.HEADER_NATIVE+ " , "
                    + QuestionEntity.HEADER_ENGLISH + " , " + QuestionEntity.T_QNO+ " , "
                    + QuestionEntity.T_DISP_SEQ + " , " + QuestionEntity.T_DIFFERAL_DAY+ " , "
                    + QuestionEntity.T_EXP_ANS + " , " + QuestionEntity.T_QNO_ANS+ " , "
                    + QuestionEntity.T_QUES_ID + " , " + QuestionEntity.T_IF_FAIL+ " , "
                    + MROW
                    + " FROM " + TABLE_QUESTION
                    + " WHERE " + QuestionEntity.HEADER_NO + " = '"+ code +"'";

            res = db.rawQuery(query, null);
            res.moveToFirst();
            while (res.isAfterLast() == false) {
                Question obj = new Question();
                obj.setR(res.getString(res.getColumnIndexOrThrow(MROW)));
                obj.setHEADER_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NO)));
                obj.setTOTAL_QUES(res.getString(res.getColumnIndexOrThrow(QuestionEntity.TOTAL_QUES)));
                obj.setQUES_NATIVE(res.getString(res.getColumnIndexOrThrow(QuestionEntity.QUES_NATIVE)));
                obj.setQUES_ENGLISH(res.getString(res.getColumnIndexOrThrow(QuestionEntity.QUES_ENGLISH)));
                obj.setT_QHEAD_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QHEAD_NO)));
                obj.setHEADER_NATIVE(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NATIVE)));
                obj.setHEADER_ENGLISH(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_ENGLISH)));
                obj.setT_QNO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QNO)));
                obj.setT_DISP_SEQ(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_DISP_SEQ)));
                obj.setT_DIFFERAL_DAY(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_DIFFERAL_DAY)));
                obj.setT_EXP_ANS(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_EXP_ANS)));
                obj.setT_QNO_ANS(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QNO_ANS)));
                obj.setT_QUES_ID(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QUES_ID)));
                obj.setT_IF_FAIL(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_IF_FAIL)));
                list.add(obj);
                res.moveToNext();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, res);
            return list;
        }
    }

    /*public boolean deleteLabelByFormName(String code) {
        SQLiteDatabase db = null;
        boolean check = false;
        try {
            String query = "delete from " + TABLE_LABEL
                    + " WHERE " + LABEL_CODE + " = '"+ code +"'";
            db = this.getWritableDatabase();
            db.execSQL(query);
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, null);
            return check;
        }
    }*/

    public boolean deleteAll() {
        SQLiteDatabase db = null;
        boolean check = false;
        try {
            String query = "delete from " + TABLE_QUESTION;
            db = this.getWritableDatabase();
            db.execSQL(query);
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, null);
            return check;
        }
    }
}
