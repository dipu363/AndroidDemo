package sa.com.medisys.bloodbankdonor.database.entity;

/*
 @author : Md. Abu Bakar Siddique
 @date : 27-OCT-2021
 @version: 1.0.0
*/

public interface QuestionHeaderEntity {

    /*==================== LABEL ====================*/
    //QUESTION
    String TABLE_QUESTION_HEADER = "QUESTION_HEADER";

    // QUESTION TABLE COLUMN NAME
    String HEADER_NO = "HEADER_NO";
    String TOTAL_QUES = "TOTAL_QUES";
    String T_QHEAD_NO = "T_QHEAD_NO";
    String HEADER_NATIVE = "HEADER_NATIVE";
    String HEADER_ENGLISH = "HEADER_ENGLISH";

    /*QUESTION table create*/
    String CREATE_TABLE_QUESTION_HEADER = "CREATE TABLE "
            + TABLE_QUESTION_HEADER + "("
            + HEADER_NO+ " TEXT ,"
            + TOTAL_QUES + " TEXT ," + T_QHEAD_NO+ " TEXT ,"
            + HEADER_NATIVE + " TEXT ," + HEADER_ENGLISH+ " TEXT " + ")";
}
