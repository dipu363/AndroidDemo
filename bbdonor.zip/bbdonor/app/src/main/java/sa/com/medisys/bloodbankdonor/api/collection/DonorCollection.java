package sa.com.medisys.bloodbankdonor.api.collection;

/*
 @author : Md. Abu Bakar Siddique
 @date : 20-AUG-2019
 @version: 1.0.0
*/


import java.io.Serializable;

import sa.com.medisys.bloodbankdonor.api.model.Donor;

public class DonorCollection implements Serializable {

    private String total;
    private Donor data;
    private String success;
    private String message;

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public Donor getData() {
        return data;
    }

    public void setData(Donor data) {
        this.data = data;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
