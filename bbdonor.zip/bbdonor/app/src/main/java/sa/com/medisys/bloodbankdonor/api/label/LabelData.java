package sa.com.medisys.bloodbankdonor.api.label;

import android.app.Dialog;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;


import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import sa.com.medisys.bloodbankdonor.api.DonorWebService;
import sa.com.medisys.bloodbankdonor.api.collection.LabelCollection;
import sa.com.medisys.bloodbankdonor.api.interfaces.DonorApi;
import sa.com.medisys.bloodbankdonor.database.service.LabelService;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;
import sa.com.medisys.bloodbankdonor.utils.CommonLabel;
import sa.com.medisys.bloodbankdonor.utils.LabelConstants;
import sa.com.medisys.bloodbankdonor.utils.MedisysToast;
import sa.com.medisys.bloodbankdonor.utils.alert.ProgressDialog;

/*
 @author : Md. Abu Bakar Siddique
 @date : 25-OCT-2021
 @version: 1.0.0
*/

public class LabelData {

    private final String TAG = this.getClass().getSimpleName();
    static  Context context;
    DonorApi api;
    private Dialog dialog;

    public LabelData(Context context) {
        this.context = context;
        this.api = new DonorWebService().webserviceInitialize();
        this.dialog = new ProgressDialog(context, TAG).createDialog();
    }

    public void getLoginLabels(final SwipeRefreshLayout swipeRefreshLayout, final boolean isNeedLoader, final Object obj, final String form) {
        Log.d(TAG, "getLoginLabels calling");

        if(isNeedLoader){
            dialog.show();
        }
        Call<LabelCollection> getInfo = api.getLoginLabels(form);
        getInfo.enqueue(new Callback<LabelCollection>() {
            @Override
            public void onResponse(Call<LabelCollection> call, Response<LabelCollection> response) {
                try{
                    LabelCollection collection = response.body();
                    Log.d(TAG,"getLoginLabels : " + collection);
                    if(collection.isSuccess()){
                        LabelService labelService = new LabelService(context);

                        /*common label*/
                        if(form.equals(LabelConstants.commonLabelFormCode)){
                            if(labelService.deleteLabelByFormName(LabelConstants.commonLabelFormCode)){
                                labelService.insertLabel(collection.getData());
                            }
//                            new CommonLabel(context).init();
                        }else if(form.equals(LabelConstants.loginActivityFormCode)){
                            if(labelService.deleteLabelByFormName(LabelConstants.loginActivityFormCode)){
                                labelService.insertLabel(collection.getData());
                            }
                           /* if(obj instanceof LoginActivity){
                                if (AppUtils.isNativeActive(context)){
                                    ((LoginActivity)obj).setNativeLabel();
                                } else {
                                    ((LoginActivity)obj).setGlobalLabel();
                                }
                            }*/
                        }
                    }else {
                        MedisysToast.makeText(context, collection.getMessage(), Toast.LENGTH_SHORT);
                    }
                } catch (Exception e){
                    AppUtils.serverMaintenance(context, e);
                }
                if(isNeedLoader){
                    dialog.dismiss();
                }
                if(swipeRefreshLayout != null){
                    swipeRefreshLayout.setRefreshing(false);
                }
            }

            @Override
            public void onFailure(Call<LabelCollection> call, Throwable t) {
                if(isNeedLoader){
                    AppUtils.onApiFailure(context, t, dialog);
                }
                if(swipeRefreshLayout != null){
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }

}
