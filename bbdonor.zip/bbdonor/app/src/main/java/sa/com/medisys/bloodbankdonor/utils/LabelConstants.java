package sa.com.medisys.bloodbankdonor.utils;

/*
 @author : Md. Abu Bakar Siddique
 @date : 02-JUN-2019
 @version: 1.0.1
*/

public interface LabelConstants {

    /*login*/
    String loginFormCode = "MM1212";

    /*login_activity*/
    String loginActivityFormCode = "login_activity";
    String loginActivityWelcomeTo = "welcomeTo";
    String loginActivityPatNoOrNationalId = "patNoOrNationalId";
    String loginActivitySignIn = "signin";
    String loginActivityEmergencyCall = "emergencyCall";
    String loginActivityToken = "token";
    String loginActivityTokenTitle = "tokenTitle";
    String loginActivitySubmit = "submit";
    String loginActivityInvalidInput= "invalidInput";

    /*common_label*/
    String commonLabelFormCode = "common_label";
    String commonLabelHospitalName = "hospitalName";
    String commonLabelEmptyField = "emptyField";
    String commonLabelNoConnection = "noConnection";
    String commonLabelServerMaintenance = "serverMaintenance";
    String commonLabelWebserviceNotRunning = "webserviceNotRunning";
    String commonLabelSlowNetwork = "slowNetwork";
    String commonLabelError = "error";
    String commonLabelOk = "ok";
    String commonLabelBackPressText = "backPressText";
    String commonLabelLogoutConfirmText = "logoutConfirmText";
    String commonLabelLvNoResultFound = "lvNoResultFound";
    String commonLabelPermissionError = "permissionError";
    String commonLabelDropdownSelectOne = "dropdownSelectOne";
    String commonLabelUpdateConfirmation = "updateConfirmation";

    /*home_activity*/
    String homeActivityFormCode = "home_activity";
    String homeActivityEdit = "edit";
    String homeActivityLogOut = "logOut";
    String homeActivityHome = "home";
    String homeActivityPatRight = "patRight";
    String homeActivityContactUs = "contactUs";
    String homeActivityHealthEducation = "healthEducation";
    String homeActivityDoctors = "doctors";
    String homeActivityIhd = "ihd";
    String homeActivityHello = "hello";
    String homeActivityPatientInfo = "patientInfo";
    String homeActivityAppointment = "appointment";
    String homeActivityMedication = "medication";
    String homeActivityReport = "report";
    String homeActivityBloodDonation = "bloodDonation";
    String homeActivityLabResults = "labResults";

    /************************ PATIENT INFORMATION ************************/
    /*pat_info_tab*/
    String patInfoTabFormCode = "pat_info_tab";
    String patInfoTabPatientInformation = "patientInformation";
    String patInfoTabMedicalHistory = "medicalHistory";
    String patInfoTabNationalAddress = "nationalAddress";
    String patInfoTabNeighbourhood = "neighbourhood";
    String patInfoTabPersonalInfo = "personalInfo";
    String patInfoTabPatNo = "patNo";
    String patInfoTabBloodGroup = "bloodGroup";
    String patInfoTabFatherName = "fatherName";
    String patInfoTabGrandFatherName = "grandFatherName";
    String patInfoTabLastName = "lastName";
    String patInfoTabMotherName = "motherName";
    String patInfoTabDob = "dob";
    String patInfoTabGender = "gender";
    String patInfoTabMaritalStatus = "maritalStatus";
    String patInfoTabReligion = "religion";
    String patInfoTabContact = "contact";
    String patInfoTabMobile1 = "mobile1";
    String patInfoTabMobile2 = "mobile2";
    String patInfoTabPhoneHome = "phoneHome";
    String patInfoTabPhoneWork = "phoneWork";
    String patInfoTabEmail = "email";
    String patInfoTabNationality = "nationality";
    String patInfoTabPatientHealthCard = "patientHealthCard";
    String patInfoTabNidIqama = "nidIqama";
    String patInfoTabIdIssueDateEng = "idIssueDateEng";
    String patInfoTabHjri = "hjri";
    String patInfoTabIssuePlace = "issuePlace";
    String patInfoTabPassport = "passport";
    String patInfoTabBirthPlace = "birthPlace";
    String patInfoTabPatientName = "patientName";
    String patInfoTabHealthCardHeader = "healthCardHeader";
    String patInfoTabName = "name";
    String patInfoTabErCont = "erCont";
    String patInfoTabDownloadFile = "downloadFile";

    /*medical_history_tab*/
    String medicalHistoryTabFormCode = "medical_history_tab";
    String medicalHistoryTabHepatitis = "hepatitis";
    String medicalHistoryTabSmoker = "smoker";
    String medicalHistoryTabDrugReaction = "drugReaction";
    String medicalHistoryTabDrugTherapy = "drugTherapy";
    String medicalHistoryTabDiabetic = "diabetic";
    String medicalHistoryTabEpileptic = "epileptic";
    String medicalHistoryTabHemophiliac = "hemophiliac";
    String medicalHistoryTabAllergy = "allergy";
    String medicalHistoryTabLastBloodDonationDate = "lastBloodDonationDate";
    String medicalHistoryTabOthers = "others";

    /*medical_history_tab*/
    String addressTabFormCode = "address_tab";
    String addressTabCity = "city";
    String addressTabDistrict = "district";
    String addressTabPostCode = "postCode";
    String addressTabBuildingNo = "buildingNo";
    String addressTabAddress = "address";
    String addressTabLocationNotEnabled = "locationNotEnabled";
    String addressTabOpenLocationSettings = "openLocationSettings";
    String addressTabCancel = "cancel";

    /*neighbour_tab*/
    String neighbourTabFormCode = "neighbour_tab";
    String neighbourTabFullName = "fullName";
    String neighbourTabAddress = "address";
    String neighbourTabCity = "city";
    String neighbourTabDistrict = "district";
    String neighbourTabRelationship = "relationship";
    String neighbourTabMobilePhoneNo = "mobilePhoneNo";

    /************************ APPOINTMENT  ************************/
    /*opd_appointment_list_tab*/
    String opdAppointmentListTabFormCode = "opd_appointment_list_tab";
    String opdAppointmentListTabAppointment = "appointment";
    String opdAppointmentListTabOPDAppointment = "oPDAppointment";
    String opdAppointmentListTabRadiologyAppointment = "radiologyAppointment";
    String opdAppointmentListTabOPDAppointmentList = "oPDAppointmentList";
    String opdAppointmentListTabOPDRescheduleList = "oPDRescheduleList";
    String opdAppointmentListTabBookAnOPDAppointment = "bookAnOPDAppointment";
    String opdAppointmentListTabOPDArrival = "oPDArrival";
    String opdAppointmentListTabAppointmentHistory = "appointmentHistory";
    String opdAppointmentListTabRadiologyAppointmentList = "radiologyAppointmentList";
    String opdAppointmentListTabRadiologyRescheduleList = "radiologyRescheduleList";
    String opdAppointmentListTabAppointmentId = "appointmentId";
    String opdAppointmentListTabClinic = "clinic";
    String opdAppointmentListTabAppointmentType = "appointmentType";
    String opdAppointmentListTabCancelAppointment = "cancelAppointment";
    String opdAppointmentListTabCancelReason = "cancelReason";
    String opdAppointmentListTabCancelAppointmentConfirm = "cancelAppointmentConfirm";
    String opdAppointmentListTabRescheduleAppointment = "rescheduleAppointment";
    String opdAppointmentListTabRescheduleReason = "rescheduleReason";
    String opdAppointmentListTabRescheduleAppointmentConfirm = "rescheduleAppointmentConfirm";
    String opdAppointmentListTabAppointmentSlip = "appointmentSlip";
    String opdAppointmentListTabPreview = "preview";
    String opdAppointmentListTabEmail = "email";

    /*opd_reschedule_list_tab*/
    String opdRescheduleListTabFormCode = "opd_reschedule_list_tab";
    String opdRescheduleListTabStatus = "status";
    String opdRescheduleListTabRequestNo = "requestNo";
    String opdRescheduleListTabNote = "note";
    String opdRescheduleListTabPreviousInfo = "previousInfo";
    String opdRescheduleListTabAppId = "appId";
    String opdRescheduleListTabClinic = "clinic";
    String opdRescheduleListTabDocName = "docName";
    String opdRescheduleListTabAppType = "appType";
    String opdRescheduleListTabTime = "time";
    String opdRescheduleListTabRescheduleInfo = "rescheduleInfo";
    String opdRescheduleListTabPending = "pending";
    String opdRescheduleListTabCancel = "cancel";
    String opdRescheduleListTabAccept = "accept";
    String opdRescheduleListTabReject = "reject";

    /*book_an_appointment_tab*/
    String bookAnAppointmentTabFormCode = "book_an_appointment_tab";
    String bookAnAppointmentTabBook = "book";
    String bookAnAppointmentTabViewProfile = "viewProfile";
    String bookAnAppointmentTabClinic = "clinic";
    String bookAnAppointmentTabSpeciality = "speciality";
    String bookAnAppointmentTabDoctor = "doctor";
    String bookAnAppointmentTabAppointmentType = "appointmentType";
    String bookAnAppointmentTabSelectClinic = "selectClinic";
    String bookAnAppointmentTabSelectSpeciality = "selectSpeciality";
    String bookAnAppointmentTabSelectAppType = "selectAppType";
    String bookAnAppointmentTabSelectionConfirmation = "selectionConfirmation";
    String bookAnAppointmentTabNoAppSlot = "noAppSlot";
    String bookAnAppointmentTabAppRescheduling = "appRescheduling";
    String bookAnAppointmentTabMorning = "morning";
    String bookAnAppointmentTabMorningTime = "morningTime";
    String bookAnAppointmentTabAfternoon = "afternoon";
    String bookAnAppointmentTabAfternoonTime = "afternoonTime";
    String bookAnAppointmentTabEvening = "evening";
    String bookAnAppointmentTabEveningTime = "eveningTime";
    String bookAnAppointmentTabSelectTime = "selectTime";
    String bookAnAppointmentTabTime = "time";
    String bookAnAppointmentTabAppointConfirmText = "appointConfirmText";
    String bookAnAppointmentTabThankYou = "thankYou";
    String bookAnAppointmentTabRefId = "refId";
    String bookAnAppointmentTabOkThanks = "okThanks";
    String bookAnAppointmentTabConfirm = "confirm";
    String bookAnAppointmentTabEdit = "edit";
    String bookAnAppointmentTabBookAppointmentConfirm = "bookAppointmentConfirm";
    String bookAnAppointmentTabRescheduleAppointmentConfirm = "rescheduleAppointmentConfirm";

    /*opd_arrival_tab*/
    String opdArrivalTabFormCode = "opd_arrival_tab";
    String opdArrivalTabAppointmentId = "appointmentId";
    String opdArrivalTabTime = "time";
    String opdArrivalTabClinic = "clinic";
    String opdArrivalTabDoctor = "doctor";
    String opdArrivalTabArrivalStatus = "arrivalStatus";
    String opdArrivalTabArrived = "arrived";

    /*appointment_history_tab*/
    String appointmentHistoryTabFormCode = "appointment_history_tab";
    String appointmentHistoryTabAppointmentId = "appointmentId";
    String appointmentHistoryTabClinic = "clinic";
    String appointmentHistoryTabDoctor = "doctor";
    String appointmentHistoryTabAppointmentType = "appointmentType";
    String appointmentHistoryTabTime = "time";
    String appointmentHistoryTabStatus = "status";
    String appointmentHistoryTabPatientArrived = "patientArrived";
    String appointmentHistoryTabCancelByPatient = "cancelByPatient";
    String appointmentHistoryTabStatusPatientNotArrived = "patientNotArrived";

    /*radiology_appointment_list_tab*/
    String radiologyAppointmentListTabFormCode = "radiology_appointment_list_tab";
    String radiologyAppointmentListTabOrderNo = "orderNo";
    String radiologyAppointmentListTabAssNo = "assNo";
    String radiologyAppointmentListTabRoom = "room";
    String radiologyAppointmentListTabTime = "time";
    String radiologyAppointmentListTabRescheduleAppointment = "rescheduleAppointment";
    String radiologyAppointmentListTabTypeRescheduleReason = "typeRescheduleReason";
    String radiologyAppointmentListTabDateFormat = "dateFormat";
    String radiologyAppointmentListTabTimeFormat = "timeFormat";
    String radiologyAppointmentListTabSelectDate = "selectDate";
    String radiologyAppointmentListTabSelectTime = "selectTime";
    String radiologyAppointmentListTabRescheduleAppointmentConfirm = "rescheduleAppointmentConfirm";

    /*radiology_reschedule_list_tab*/
    String radiologyRescheduleListTabFormCode = "radiology_reschedule_list_tab";
    String radiologyRescheduleListTabStatus = "status";
    String radiologyRescheduleListTabReqNo = "reqNo";
    String radiologyRescheduleListTabNote = "note";
    String radiologyRescheduleListTabPreviousInfo = "previousInfo";
    String radiologyRescheduleListTabOrderNo = "orderNo";
    String radiologyRescheduleListTabRoom = "room";
    String radiologyRescheduleListTabTime = "time";
    String radiologyRescheduleListTabRescheduleInfo = "rescheduleInfo";
    String radiologyRescheduleListTabReason = "reason";

    /*appointment_remainder_activity*/
    String appointmentRemainderActivityFormCode = "appointment_remainder_activity";
    String appointmentRemainderActivityHeaderText = "headerText";
    String appointmentRemainderActivityAppointmentId = "appointmentId";
    String appointmentRemainderActivityClinic = "clinic";
    String appointmentRemainderActivityDoctorName = "doctorName";
    String appointmentRemainderActivityAppointmentTime = "appointmentTime";
    String appointmentRemainderActivityOk = "ok";

    /************************ MEDICATION  ************************/
    /*prescription_tab*/
    String prescriptionTabFormCode = "prescription_tab";
    String prescriptionTabMedication = "medication";
    String prescriptionTabPrescription = "prescription";
    String prescriptionTabCurrentMedication = "currentMedication";
    String prescriptionTabRefillMedication = "refillMedication";
    String prescriptionTabTrackingNumber = "trackingNumber";
    String prescriptionTabSlipNo = "slipNo";
    String prescriptionTabDate = "date";
    String prescriptionTabAll = "all";
    String prescriptionTabTotalQty = "totalQty";
    String prescriptionTabPrintDate = "printDate";
    String prescriptionTabLoc = "loc";
    String prescriptionTabRefillQty = "refillQty";
    String prescriptionTabNoMedicineFound = "noMedicineFound";
    String prescriptionTabInstruction = "instruction";

    /*current_medication_tab*/
    String currentMedicationTabFormCode = "current_medication_tab";
    String currentMedicationTabAlarm = "alarm";
    String currentMedicationTabCurrentMedication = "currentMedication";
    String currentMedicationTabMedicineName = "medicineName";
    String currentMedicationTabDetails = "details";
    String currentMedicationTabDate = "date";
    String currentMedicationTabRemarks = "remarks";
    String currentMedicationTabInstruction = "instruction";
    String currentMedicationTabSetMedicationAlarm = "setMedicationAlarm";
    String currentMedicationTabFrequency = "frequency";
    String currentMedicationTabDuration = "duration";
    String currentMedicationTabSetAlarm = "setAlarm";
    String currentMedicationTabOn = "on";
    String currentMedicationTabOff = "off";
    String currentMedicationTabSetTime = "setTime";
    String currentMedicationTabUnableToSetTime = "unableToSetTime";
    String currentMedicationTabAlarmOn = "alarmOn";
    String currentMedicationTabAlarmOff = "alarmOff";

    /*refill_medication_tab*/
    String refillMedicationTabFormCode = "refill_medication_tab";
    String refillMedicationTabToConfirm = "toConfirm";
    String refillMedicationTabDetails = "details";
    String refillMedicationTabRequestNo = "requestNo";
    String refillMedicationTabMedicine = "medicine";
    String refillMedicationTabQuantity = "quantity";
    String refillMedicationTabConfirm = "confirm";
    String refillMedicationTabSelectReceiveType = "selectReceiveType";
    String refillMedicationTabOrderConfirm = "orderConfirm";
    String refillMedicationTabAddAddress = "addAddress";
    String refillMedicationTabSelectAddressType = "selectAddressType";
    String refillMedicationTabTypeCity = "typeCity";
    String refillMedicationTabTypePostCode = "typePostCode";
    String refillMedicationTabTypeBuildingNo = "typeBuildingNo";
    String refillMedicationTabTypeDistrict = "typeDistrict";
    String refillMedicationTabTypeAddress = "typeAddress";
    String refillMedicationTabTypeMobileNo = "typeMobileNo";
    String refillMedicationTabSelectNationality = "selectNationality";
    String refillMedicationTabDelete = "delete";
    String refillMedicationTabDeleteConfirm = "deleteConfirm";
    String refillMedicationTabDefaultAddress = "defaultAddress";
    String refillMedicationTabAddress = "address";
    String refillMedicationTabPostalCode = "postalCode";
    String refillMedicationTabBuildingNo = "buildingNo";
    String refillMedicationTabCity = "city";
    String refillMedicationTabDistrict = "district";
    String refillMedicationTabDefaultAddressEmptyMsg = "defaultAddressEmptyMsg";

    String refillMedicationTabToShip = "toShip";
    String refillMedicationTabReceiveType = "receiveType";
    String refillMedicationTabTrackingNo = "trackingNo";
    String refillMedicationTabShipsIn = "shipsIn";
    String refillMedicationTabShippingInformation = "shippingInformation";

    String refillMedicationTabToReceive = "toReceive";
    String refillMedicationTabConfirmReceive = "confirmReceive";
    String refillMedicationTabShipmentStatus = "shipmentStatus";
    String refillMedicationTabSelectReceiveStatus = "selectReceiveStatus";
    String refillMedicationTabTypeRemark = "typeRemark";

    String refillMedicationTabCompleted = "completed";
    String refillMedicationTabStatus = "status";
    String refillMedicationTabReceiveNote = "receiveNote";

    String refillMedicationTabOrderDetail = "orderDetail";
    String refillMedicationTabPending = "pending";
    String refillMedicationTabDelivered = "delivered";

    /*tracking_number_tab*/
    String trackingNumberTabFormCode = "tracking_number_tab";
    String trackingNumberTabTrackingNumber= "trackingNumber";
    String trackingNumberTabView = "view";
    String trackingNumberTabSelectTrackingNumber = "selectTrackingNumber";

    /*medication_alarm_activity*/
    String medicationAlarmActivityFormCode = "medication_alarm_activity";
    String medicationAlarmActivityHeaderText = "headerText";
    String medicationAlarmActivityMedicineName = "medicineName";
    String medicationAlarmActivityDoseUnit = "doseUnit";
    String medicationAlarmActivityFrequency = "frequency";
    String medicationAlarmActivityDuration = "duration";

    /************************ REPORT  ************************/
    /*laboratory_report_tab*/
    String laboratoryReportTabFormCode = "laboratory_report_tab";
    String laboratoryReportTabReportAndSickLeave = "reportAndSickLeave";
    String laboratoryReportTabLaboratoryReport = "laboratoryReport";
    String laboratoryReportTabRadiologyReport = "radiologyReport";
    String laboratoryReportTabMedicalReport = "medicalReport";
    String laboratoryReportTabSickLeave = "sickLeave";
    String laboratoryReportTabVisitNotification = "visitNotification";
    String laboratoryReportTabMarriageTest = "marriageTest";
    String laboratoryReportTabPDFReports = "pDFReports";
    String laboratoryReportTabALL = "all";
    String laboratoryReportTabRequestId = "requestId";
    String laboratoryReportTabDate = "date";
    String laboratoryReportTabAnalysis = "analysis";
    String laboratoryReportTabSpecimen = "specimen";
    String laboratoryReportTabStatus = "status";

    /*radiology_report_tab*/
    String radiologyReportTabFormCode = "radiology_report_tab";
    String radiologyReportTabALL = "all";
    String radiologyReportTabOrderID = "orderID";
    String radiologyReportTabDate = "date";
    String radiologyReportTabProcedure = "procedure";
    String radiologyReportTabResultNote = "resultNote";

    /*medical_report_tab*/
    String medicalReportTabFormCode = "medical_report_tab";
    String medicalReportTabAdmitDate = "admitDate";
    String medicalReportTabComment = "comment";

    /*sick_leave_tab*/
    String sickLeaveTabFormCode = "sick_leave_tab";
    String sickLeaveTabDate = "date";
    String sickLeaveTabApproved = "approved";

    /*visit_notification_tab*/
    String visitNotificationTabFormCode = "visit_notification_tab";
    String visitNotificationTabAppDate = "appDate";
    String visitNotificationTabDocName = "docName";

    /*visit_notification_tab*/
    String marriageTestTabFormCode = "marriage_test_tab";
    String marriageTestTabSerialNo = "serialNo";
    String marriageTestTabStatus = "status";
    String marriageTestTabPending = "pending";
    String marriageTestTabResultCompleted = "resultCompleted";
    String marriageTestTabDate = "date";
    String marriageTestTabLocation = "location";
    String marriageTestTabViewReport = "viewReport";

    /* *********************** NAVIGATION DRAWER DIALOG *********************** */
    /*patient_rights_dialog*/
    String patientRightsDialogFormCode = "patient_rights_dialog";
    String patientRightsDialogPatientRights = "patientRights";
    String patientRightsDialogSuggestion = "suggestion";
    String patientRightsDialogComplaint = "complaint";
    String patientRightsDialogAppreciationAndCredits = "appreciationAndCredits";
    String patientRightsDialogNotesOrInquiries = "notesOrInquiries";
    String patientRightsDialogAllTheRightOfPatient = "allTheRightOfPatient";
    String patientRightsDialogSuggestionOptions = "suggestionOptions";
    String patientRightsDialogPendingSuggestion = "pendingSuggestion";
    String patientRightsDialogResolvedSuggestion = "resolvedSuggestion";
    String patientRightsDialogComplaintsOptions = "complaintsOptions";
    String patientRightsDialogPendingComplaint = "pendingComplaint";
    String patientRightsDialogResolvedComplaint = "resolvedComplaint";
    String patientRightsDialogDeclinedComplaint = "declinedComplaint";
    String patientRightsDialogUpdate = "update";
    String patientRightsDialogDelete = "delete";
    String patientRightsDialogUpdateConfirm = "updateConfirm";
    String patientRightsDialogDeleteConfirm = "deleteConfirm";
    String patientRightsDialogAppreciationOptions = "appreciationOptions";
    String patientRightsDialogPendingAppreciation = "pendingAppreciation";
    String patientRightsDialogResolvedAppreciation = "resolvedAppreciation";
    String patientRightsDialogInquiriesOptions = "inquiriesOptions";
    String patientRightsDialogPendingInquiries = "pendingInquiries";
    String patientRightsDialogResolvedInquiries = "resolvedInquiries";
    String patientRightsDialogReply = "reply";
    String patientRightsDialogNew = "new";
    String patientRightsDialogPending = "pending";
    String patientRightsDialogResolved = "resolved";
    String patientRightsDialogDeclined = "declined";
    String patientRightsDialogTypeSubject = "typeSubject";
    String patientRightsDialogTypeDescription = "typeDescription";
    String patientRightsDialogSend = "send";
    String patientRightsDialogIssueNo = "issueNo";
    String patientRightsDialogSubject = "subject";
    String patientRightsDialogDescription = "description";
    String patientRightsDialogRegNo = "regNo";

    /*contact_us_dialog*/
    String contactUsDialogFormCode = "contact_us_dialog";
    String contactUsDialogDepartment = "department";
    String contactUsDialogTitle = "title";
    String contactUsDialogInstruction = "instruction";
    String contactUsDialogMorningShift = "morningShift";
    String contactUsDialogMorningShiftMobile1 = "morningShiftMobile1";
    String contactUsDialogMorningShiftMobile2 = "morningShiftMobile2";
    String contactUsDialogEveningShift = "eveningShift";
    String contactUsDialogEveningShiftMobile1 = "eveningShiftMobile1";
    String contactUsDialogEveningShiftMobile2 = "eveningShiftMobile2";
    String contactUsDialogSpecialCare = "specialCare";
    String contactUsDialogSpecialCareMobile = "specialCareMobile";

    /*health_education_dialog*/
    String healthEducationDialogFormCode = "health_education_dialog";
    String healthEducationDialogHealthEducation = "healthEducation";
    String healthEducationDialogHealthEducationList = "healthEducationList";
    String healthEducationDialogBaseOnDiagnosis = "baseOnDiagnosis";
    String healthEducationDialogDailyEducation = "dailyEducation";
    String healthEducationDialogAdvertisement = "advertisement";
    String healthEducationDialogVideo = "video";
    String healthEducationDialogDisease = "disease";
    String healthEducationDialogFood = "food";
    String healthEducationDialogProblemSpecialities = "problemSpecialities";
    String healthEducationDialogProhibitedItems = "prohibitedItems";
    String healthEducationDialogGeneric = "generic";
    String healthEducationDialogICD10 = "iCD10";
    String healthEducationDialogDiseaseEffect = "diseaseEffect";
    String healthEducationDialogFoodEffect = "foodEffect";
    String healthEducationDialogProhibitedName = "prohibitedName";
    String healthEducationDialogWarning = "warning";

    /*physicians_information_dialog*/
    String physiciansInformationDialogFormCode = "physicians_information_dialog";
    String physiciansInformationDialogPhysiciansInformation = "physiciansInformation";
    String physiciansInformationDialogViewProfile = "viewProfile";
    String physiciansInformationDialogProfileNotAvailable = "profileNotAvailable";

}
