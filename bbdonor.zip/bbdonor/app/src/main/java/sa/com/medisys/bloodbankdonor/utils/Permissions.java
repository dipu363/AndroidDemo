package sa.com.medisys.bloodbankdonor.utils;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;

/*
 @author : Md. Abu Bakar Siddique
 @date : 02-JUN-2019
 @version: 1.0.1
*/

public class Permissions extends Activity {

    private static final String TAG = "Permissions";

    private Context context;
    String [] permissions = new String[] {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            /*Manifest.permission.READ_PHONE_STATE,*/
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.CALL_PHONE
    };

    public Permissions(Context context) {
        this.context = context;
    }

    public void checkPermission() {
        ActivityCompat.requestPermissions((Activity) context, permissions,100);
    }

    @TargetApi(27)
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 100:
                if (grantResults.length > 0
                        || grantResults[0] == PackageManager.PERMISSION_GRANTED
                        || grantResults[1] == PackageManager.PERMISSION_GRANTED
                        || grantResults[2] == PackageManager.PERMISSION_GRANTED
                        || grantResults[3] == PackageManager.PERMISSION_GRANTED
                    /*|| grantResults[3] == PackageManager.PERMISSION_GRANTED*/
                ) {

                } else {
                    Toast.makeText(context, "Permission is denied.", Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
    }

    public  boolean hasPermissions(){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && context != null && permissions != null)
            for (String permission : permissions)
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED)
                    return false;
        return true;
    }
}

