package sa.com.medisys.bloodbankdonor.api.model;

import java.io.Serializable;

public class Donor implements Serializable {

    private String T_PAT_NO;
    private String T_GENDER;
    private String NAME_ENGLISH;
    private String NAME_NATIVE;
    private String T_EPISODE_NO;
    private String T_DONATION_SEQ_NO;
    private String T_DONOR_NTNLTY_ID;

    public String getT_PAT_NO() {
        return T_PAT_NO;
    }

    public void setT_PAT_NO(String t_PAT_NO) {
        T_PAT_NO = t_PAT_NO;
    }

    public String getT_GENDER() {
        return T_GENDER;
    }

    public void setT_GENDER(String t_GENDER) {
        T_GENDER = t_GENDER;
    }

    public String getNAME_ENGLISH() {
        return NAME_ENGLISH;
    }

    public void setNAME_ENGLISH(String NAME_ENGLISH) {
        this.NAME_ENGLISH = NAME_ENGLISH;
    }

    public String getNAME_NATIVE() {
        return NAME_NATIVE;
    }

    public void setNAME_NATIVE(String NAME_NATIVE) {
        this.NAME_NATIVE = NAME_NATIVE;
    }

    public String getT_EPISODE_NO() {
        return T_EPISODE_NO;
    }

    public void setT_EPISODE_NO(String t_EPISODE_NO) {
        T_EPISODE_NO = t_EPISODE_NO;
    }

    public String getT_DONATION_SEQ_NO() {
        return T_DONATION_SEQ_NO;
    }

    public void setT_DONATION_SEQ_NO(String t_DONATION_SEQ_NO) {
        T_DONATION_SEQ_NO = t_DONATION_SEQ_NO;
    }

    public String getT_DONOR_NTNLTY_ID() {
        return T_DONOR_NTNLTY_ID;
    }

    public void setT_DONOR_NTNLTY_ID(String t_DONOR_NTNLTY_ID) {
        T_DONOR_NTNLTY_ID = t_DONOR_NTNLTY_ID;
    }
}
