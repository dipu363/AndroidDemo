package sa.com.medisys.bloodbankdonor.utils;

import android.content.Context;
import android.text.TextUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
 @author : Md. Abu Bakar Siddique
 @date : 28-AUG-2019
 @version: 1.0.0
*/

public class MedisysDateUtils {

    /*
    METHOD : ConvertToDate
        public static String INPUTE_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
        public static String FORMAT_FOR_JOB_APPLIED = "MMM dd, yyyy";
        String date ="2017-10-29";

        ConvertToDate(date ,MedisysDateUtils.INPUTE_DATE_FORMAT, MedisysDateUtils.FORMAT_FOR_JOB_APPLIED);
        You can put any format you want in your situation

        ConvertToDate("2011-11-30","yyyy/mm/dd" ,"mm/dd/yyyy");
    */

    public static String ConvertToDate(String dateString, String inputFormater ,String outputFormater) {
        String outputText = "" ;
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat(inputFormater);
            SimpleDateFormat outputFormat = new SimpleDateFormat(outputFormater);
            Date parsed = null;
            parsed = inputFormat.parse(dateString);
            outputText = outputFormat.format(parsed);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return outputText;
    }

    /*
    METHOD : convertToArabicDate

    */
    public static String convertToArabicDate(String dateValue, String dateSeparator) {
        String date = "";
        String[] d = dateValue.split(dateSeparator);
        String dd = convertToArabic(d[0]);
        String mm = convertToArabic(d[1]);
        String yyyy = convertToArabic(d[2]);
        date = dd + dateSeparator + mm + dateSeparator + yyyy;
        return date;
    }

    private static String convertToArabic(String value)
    {
        String newValue = (((((((((((value+"")
                .replaceAll("1", "١")).replaceAll("2", "٢"))
                .replaceAll("3", "٣")).replaceAll("4", "٤"))
                .replaceAll("5", "٥")).replaceAll("6", "٦"))
                .replaceAll("7", "٧")).replaceAll("8", "٨"))
                .replaceAll("9", "٩")).replaceAll("0", "٠"));
        return newValue;
    }

    /*public static String convertGregorianToHijriDate(Context context, String date, String dateSeparator) {
        if(TextUtils.isEmpty(date)){
            return  "";
        }
        JodaTimeAndroid.init(context);

        String[] d = date.split(dateSeparator);
        int dd = Integer.parseInt(d[0]);
        if(dd <= 30) {
            dd += 1;
        }
        int mm = Integer.parseInt(d[1]);
        int yyyy = Integer.parseInt(d[2]);

        Chronology iso = ISOChronology.getInstanceUTC();
        Chronology hijri = IslamicChronology.getInstanceUTC();

        LocalDate todayIso = new LocalDate(yyyy, mm, dd, iso);
        LocalDate todayHijri = new LocalDate(todayIso.toDateTimeAtStartOfDay(), hijri);

        return todayHijri.toString();
    }*/
}
