package sa.com.medisys.bloodbankdonor.api.model;

import java.io.Serializable;

public class Question implements Serializable {

    private String R;
    private String HEADER_NO;
    private String TOTAL_QUES;
    private String QUES_NATIVE;
    private String QUES_ENGLISH;
    private String T_QHEAD_NO;
    private String HEADER_NATIVE;
    private String HEADER_ENGLISH;
    private String T_QNO;
    private String T_DISP_SEQ;
    private String T_DIFFERAL_DAY;
    private String T_EXP_ANS;
    private String T_QNO_ANS;
    private String T_QUES_ID;
    private String T_IF_FAIL;

    public Question() {
    }

    public Question(String r, String HEADER_NO, String TOTAL_QUES, String QUES_NATIVE, String QUES_ENGLISH, String t_QHEAD_NO, String HEADER_NATIVE, String HEADER_ENGLISH, String t_QNO, String t_DISP_SEQ, String t_DIFFERAL_DAY, String t_EXP_ANS, String t_QNO_ANS, String t_QUES_ID, String t_IF_FAIL) {
        R = r;
        this.HEADER_NO = HEADER_NO;
        this.TOTAL_QUES = TOTAL_QUES;
        this.QUES_NATIVE = QUES_NATIVE;
        this.QUES_ENGLISH = QUES_ENGLISH;
        T_QHEAD_NO = t_QHEAD_NO;
        this.HEADER_NATIVE = HEADER_NATIVE;
        this.HEADER_ENGLISH = HEADER_ENGLISH;
        T_QNO = t_QNO;
        T_DISP_SEQ = t_DISP_SEQ;
        T_DIFFERAL_DAY = t_DIFFERAL_DAY;
        T_EXP_ANS = t_EXP_ANS;
        T_QNO_ANS = t_QNO_ANS;
        T_QUES_ID = t_QUES_ID;
        T_IF_FAIL = t_IF_FAIL;
    }

    public String getR() {
        return R;
    }

    public void setR(String r) {
        R = r;
    }

    public String getHEADER_NO() {
        return HEADER_NO;
    }

    public void setHEADER_NO(String HEADER_NO) {
        this.HEADER_NO = HEADER_NO;
    }

    public String getTOTAL_QUES() {
        return TOTAL_QUES;
    }

    public void setTOTAL_QUES(String TOTAL_QUES) {
        this.TOTAL_QUES = TOTAL_QUES;
    }

    public String getQUES_NATIVE() {
        return QUES_NATIVE;
    }

    public void setQUES_NATIVE(String QUES_NATIVE) {
        this.QUES_NATIVE = QUES_NATIVE;
    }

    public String getQUES_ENGLISH() {
        return QUES_ENGLISH;
    }

    public void setQUES_ENGLISH(String QUES_ENGLISH) {
        this.QUES_ENGLISH = QUES_ENGLISH;
    }

    public String getT_QHEAD_NO() {
        return T_QHEAD_NO;
    }

    public void setT_QHEAD_NO(String t_QHEAD_NO) {
        T_QHEAD_NO = t_QHEAD_NO;
    }

    public String getHEADER_NATIVE() {
        return HEADER_NATIVE;
    }

    public void setHEADER_NATIVE(String HEADER_NATIVE) {
        this.HEADER_NATIVE = HEADER_NATIVE;
    }

    public String getHEADER_ENGLISH() {
        return HEADER_ENGLISH;
    }

    public void setHEADER_ENGLISH(String HEADER_ENGLISH) {
        this.HEADER_ENGLISH = HEADER_ENGLISH;
    }

    public String getT_QNO() {
        return T_QNO;
    }

    public void setT_QNO(String t_QNO) {
        T_QNO = t_QNO;
    }

    public String getT_DISP_SEQ() {
        return T_DISP_SEQ;
    }

    public void setT_DISP_SEQ(String t_DISP_SEQ) {
        T_DISP_SEQ = t_DISP_SEQ;
    }

    public String getT_DIFFERAL_DAY() {
        return T_DIFFERAL_DAY;
    }

    public void setT_DIFFERAL_DAY(String t_DIFFERAL_DAY) {
        T_DIFFERAL_DAY = t_DIFFERAL_DAY;
    }

    public String getT_EXP_ANS() {
        return T_EXP_ANS;
    }

    public void setT_EXP_ANS(String t_EXP_ANS) {
        T_EXP_ANS = t_EXP_ANS;
    }

    public String getT_QNO_ANS() {
        return T_QNO_ANS;
    }

    public void setT_QNO_ANS(String t_QNO_ANS) {
        T_QNO_ANS = t_QNO_ANS;
    }

    public String getT_QUES_ID() {
        return T_QUES_ID;
    }

    public void setT_QUES_ID(String t_QUES_ID) {
        T_QUES_ID = t_QUES_ID;
    }

    public String getT_IF_FAIL() {
        return T_IF_FAIL;
    }

    public void setT_IF_FAIL(String t_IF_FAIL) {
        T_IF_FAIL = t_IF_FAIL;
    }
}
