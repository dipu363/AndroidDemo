package sa.com.medisys.bloodbankdonor.activity.questionary.ui.main;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import sa.com.medisys.bloodbankdonor.R;
import sa.com.medisys.bloodbankdonor.activity.questionary.QuestionaryActivity;
import sa.com.medisys.bloodbankdonor.activity.questionary.adapter.CustomAdapter;
import sa.com.medisys.bloodbankdonor.api.DonorWebService;
import sa.com.medisys.bloodbankdonor.api.collection.QuestionCollection;
import sa.com.medisys.bloodbankdonor.api.interfaces.DonorApi;
import sa.com.medisys.bloodbankdonor.api.model.Question;
import sa.com.medisys.bloodbankdonor.database.service.QuestionHeaderService;
import sa.com.medisys.bloodbankdonor.database.service.QuestionService;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;
import sa.com.medisys.bloodbankdonor.utils.DonorPreferenceManager;
import sa.com.medisys.bloodbankdonor.utils.MedisysToast;
import sa.com.medisys.bloodbankdonor.utils.alert.ProgressDialog;


public class Fragment_for_question extends Fragment implements View.OnClickListener {


    ListView listView;

    Button buttonNext;
    private final String TAG = this.getClass().getSimpleName();
    private DonorPreferenceManager memory;
    private Dialog dialog;
    private DonorApi api;

    private CustomAdapter mAdapter;

    List<Integer> headerNolist;
    List<Question> qsHeadList = new ArrayList<>();

    QuestionService questionService;
    QuestionHeaderService qHeaderService;

    public Fragment_for_question() {

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        memory = new DonorPreferenceManager(getContext());
        dialog = new ProgressDialog(getContext(), TAG).createDialog();
        api = new DonorWebService().webserviceInitialize();
        mAdapter = new CustomAdapter(getContext());
        questionService = new QuestionService(getContext());
        qHeaderService = new QuestionHeaderService(getContext());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view =inflater.inflate(R.layout.fragment_for_question, container, false);

        listView = view.findViewById(R.id.ques_list_view_id);
        buttonNext = view.findViewById(R.id.btn_fragment_done_id);

        buttonNext.setOnClickListener(this);



        getAllQuestions(memory.getPref(DonorPreferenceManager.KEY_GENDER), memory.getPref(DonorPreferenceManager.KEY_DONOR_ID),
                memory.getPref(DonorPreferenceManager.KEY_LANG_CODE));

       return view;
    }

    List<Question> qs = new ArrayList<>();
    int h = 0;


    private void getAllQuestions(String gender, String patNo, String lang) {
        dialog.show();
        Call<QuestionCollection> getInfo = api.getQuestionList(gender, patNo, lang);
        getInfo.enqueue(new Callback<QuestionCollection>() {
            @Override
            public void onResponse(Call<QuestionCollection> call, Response<QuestionCollection> response) {
                try{
                    QuestionCollection collection = response.body();
                    Log.d(TAG,"success : " + collection.getSuccess());

                    if(collection.getSuccess().equals("true")){
                        Log.d(TAG, "message : " + collection.getMessage());

                        QuestionService questionService = new QuestionService(getContext());
                        questionService.deleteAll();

                        questionService.insertQuestion(collection.getData());
                        Log.d(TAG, "insertQuestion : DONE");

                        QuestionHeaderService qHeaderService = new QuestionHeaderService(getContext());
                        qHeaderService.deleteAll();

                        List<Question> q =  collection.getData();

                        Set<Integer> headerUniqueSet = new HashSet<Integer>();
                        for (int i = 0; i < q.size(); i++) {
                            //Log.d("question", "" + q.get(i).getHEADER_NO() + " :: " + q.get(i).getTOTAL_QUES() + " :: " + q.get(i).getT_QNO());

                            headerUniqueSet.add(Integer.parseInt(q.get(i).getHEADER_NO()));


                        }
                        Log.d("headerlistSize", "" + headerUniqueSet.size());

                        headerNolist = new ArrayList<Integer>(headerUniqueSet);
                        for(int i = 0; i < headerNolist.size(); i++){
                            Question qs = new Question();
                            qs.setHEADER_NO(headerNolist.get(i).toString());
                            qsHeadList.add(qs);
                        }

                        qHeaderService.insertQuestionHeader(qsHeadList);



                        /*hide dialog*/
                        dialog.dismiss();

                    }else {
                        MedisysToast.makeText(getContext(), collection.getMessage(), Toast.LENGTH_SHORT);
                    }
                }catch (Exception e){
                    AppUtils.serverMaintenance(getContext(), e);
                }

                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                /*hide dialog*/
                dialog.dismiss();
            }

            @Override
            public void onFailure(Call<QuestionCollection> call, Throwable t) {
                AppUtils.onApiFailure(getContext(), t, dialog);
            }
        });


        qs.clear();
        mAdapter.notifyDataSetChanged();

        List<Question> qh = qHeaderService.getQHeader();
        Log.d(TAG, "qh.size() :: " + qh.size());

        if (h <= qh.size()) {
            loadListView(qh.get(h).getHEADER_NO());
            h++;
        }

    }





    private void loadListView(String h) {

        qs = questionService.getQuestionsByHeaderNo(h);
        mAdapter.addSectionHeaderItem(new Question(null, null, null, null,
                null, null, null, qs.get(0).getHEADER_ENGLISH(), null,
                null, null, null, null, null, null));

        for (int i = 0; i < qs.size(); i++) {
            mAdapter.addItem(new Question(qs.get(i).getR(), qs.get(i).getHEADER_NO(), qs.get(i).getTOTAL_QUES(),
                    qs.get(i).getQUES_NATIVE(),
                    qs.get(i).getQUES_ENGLISH(), qs.get(i).getT_QHEAD_NO(), qs.get(i).getHEADER_NATIVE(), qs.get(i).getHEADER_ENGLISH(),
                    qs.get(i).getT_QNO(),
                    qs.get(i).getT_DISP_SEQ(), qs.get(i).getT_DIFFERAL_DAY(), qs.get(i).getT_EXP_ANS(), qs.get(i).getT_QNO_ANS(),
                    qs.get(i).getT_QUES_ID(), qs.get(i).getT_IF_FAIL()));
        }

        listView.setAdapter(mAdapter);
    }


    @Override
    public void onClick(View view) {

        if (view.getId() == R.id.btn_fragment_done_id) {

            qs.clear();
            mAdapter.notifyDataSetChanged();

            List<Question> qh = qHeaderService.getQHeader();
            Log.d(TAG, "qh.size() :: " + qh.size());

            if (h <= qh.size()) {
                loadListView(qh.get(h).getHEADER_NO());
                h++;
            }

        }
    }
}

