package sa.com.medisys.bloodbankdonor.utils;

public interface AppConstants {
    String LANG = "lang";
    String SITE_CODE = "siteCode";
}
