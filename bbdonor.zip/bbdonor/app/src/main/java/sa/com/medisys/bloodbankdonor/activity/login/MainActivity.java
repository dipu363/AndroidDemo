package sa.com.medisys.bloodbankdonor.activity.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

import sa.com.medisys.bloodbankdonor.R;
import sa.com.medisys.bloodbankdonor.api.label.LabelData;
import sa.com.medisys.bloodbankdonor.api.model.Label;
import sa.com.medisys.bloodbankdonor.database.service.LabelService;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;
import sa.com.medisys.bloodbankdonor.utils.CommonLabel;
import sa.com.medisys.bloodbankdonor.utils.LabelConstants;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();
    Context context;
    boolean hardwareBackControl;

    /*label*/
    LabelData labelData;
    LabelService labelService;

    EditText edtUsername;
    EditText edtPassword;

    Button btnLogin;
    DoLogin doLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
    }

    private void initialize() {
        context = MainActivity.this;

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        doLogin = new DoLogin(context);

        /*label*/
        labelData = new LabelData(context);
        labelService = new LabelService(context);

        if (labelService.getLabelByFormName(LabelConstants.loginFormCode).size() <= 0 && AppUtils.isConnected(context)) {
            Log.d(TAG, "loginFormCode:: " + LabelConstants.loginFormCode);
            labelData.getLoginLabels(null, true, null, LabelConstants.loginFormCode);
        }
        if (AppUtils.isNativeActive(context)){
            setNativeLabel();
        } else {
            setGlobalLabel();
        }

    }

    /***************** << HELPER >> *****************/
    public void setNativeLabel() {
        List<Label> loginLabels = new LabelService(context).getLabelByFormName(LabelConstants.loginFormCode);
        if(loginLabels.size() <= 0){
            return;
        }
//        tvUserFullName.setText(patBasicData.getFirstNameNative() + " "+patBasicData.getLastNameNative());
        for (Label label : loginLabels){
            Log.d(TAG, "CODE:: " + label.getCODE() + "NATIVE:: " + label.getNAME_NATIVE());
        }
    }

    public void setGlobalLabel() {
        List<Label> loginLabels = new LabelService(context).getLabelByFormName(LabelConstants.loginFormCode);
        if(loginLabels.size() <= 0){
            return;
        }
//        tvUserFullName.setText(patBasicData.getFirstNameGlobal() + " "+patBasicData.getLastNameGlobal());

        for (Label label : loginLabels){
            Log.d(TAG, "CODE:: " + label.getCODE() + " GLOBAL :: " + label.getNAME_NATIVE());
        }


        /*for (Label label : loginLabels){
            switch (label.getObjectName()){
                case LabelConstants.homeActivityEdit:
                    tvEdit.setText(label.getLabelGlobal());
                    break;
                case LabelConstants.homeActivityLogOut:
                    tvLogout.setText(label.getLabelGlobal());
                    break;
                case LabelConstants.homeActivityHome:
                    menu.findItem(R.id.nav_home).setTitle(label.getLabelGlobal());
                    break;
                case LabelConstants.homeActivityPatRight:
                    menu.findItem(R.id.nav_patient_right).setTitle(label.getLabelGlobal());
                    break;
                case LabelConstants.homeActivityContactUs:
                    menu.findItem(R.id.nav_contract_us).setTitle(label.getLabelGlobal());
                    break;
                case LabelConstants.homeActivityHealthEducation:
                    menu.findItem(R.id.nav_health_eduction).setTitle(label.getLabelGlobal());
                    break;
                case LabelConstants.homeActivityDoctors:
                    menu.findItem(R.id.nav_doctors).setTitle(label.getLabelGlobal());
                    break;
                case LabelConstants.homeActivityIhd:
                    menu.findItem(R.id.nav_ihd).setTitle(label.getLabelGlobal());
                    break;

            }
        }*/
    }

    @Override
    public void onClick(View v) {
        loginProcess();
    }

    private void loginProcess(){
        String userId = edtUsername.getText().toString();
        if(userId.isEmpty()){
            String emptyText = AppUtils.isNativeActive(context)? CommonLabel.emptyFieldNative :  CommonLabel.emptyFieldGlobal;
            edtUsername.setError(emptyText);
            return;
        }

        String pass = edtPassword.getText().toString();
        if(userId.isEmpty()){
            String emptyText = AppUtils.isNativeActive(context)? CommonLabel.emptyFieldNative :  CommonLabel.emptyFieldGlobal;
            edtPassword.setError(emptyText);
            return;
        }

        if (AppUtils.isConnected(context)) {
            doLogin.login(userId, pass);
        }else {
            AppUtils.noNetworkConnection(context);
        }
    }
}