package sa.com.medisys.bloodbankdonor.api.collection;

/*
 @author : Md. Abu Bakar Siddique
 @date : 25-OCT-2021
 @version: 1.0.0
*/


import java.util.List;

import sa.com.medisys.bloodbankdonor.api.model.Label;

public class LabelCollection {

    private int total;
    private List<Label> data;
    private boolean success;
    private String message;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<Label> getData() {
        return data;
    }

    public void setData(List<Label> data) {
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return  success+"";
    }
}
