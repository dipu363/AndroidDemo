package sa.com.medisys.bloodbankdonor.api.collection;

import java.io.Serializable;
import java.util.List;

import sa.com.medisys.bloodbankdonor.api.model.Question;


public class QuestionCollection implements Serializable {

    private String total;
    private List<Question> data;
    private String success;
    private String message;

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public List<Question> getData() {
        return data;
    }

    public void setData(List<Question> data) {
        this.data = data;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
