package sa.com.medisys.bloodbankdonor.database.service;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import sa.com.medisys.bloodbankdonor.api.model.Question;
import sa.com.medisys.bloodbankdonor.database.AppDatabaseSchema;
import sa.com.medisys.bloodbankdonor.database.entity.QuestionEntity;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;

/*
 @author : Md. Abu Bakar Siddique
 @date : 27-OCT-2021
 @version: 1.0.0
*/

public class QuestionHeaderService extends AppDatabaseSchema {
    private final String TAG = this.getClass().getSimpleName();

    public QuestionHeaderService(Context context) {
        super(context);
    }

    public boolean insertQuestionHeader(List<Question> list) {
        SQLiteDatabase db = null;
        SQLiteStatement stmt = null;
        boolean check = false;
        try {
            db = this.getWritableDatabase();
            db.beginTransactionNonExclusive();

            String sql = "INSERT INTO " + TABLE_QUESTION_HEADER + " ( "
                    + QuestionEntity.HEADER_NO+ " , "
                    + QuestionEntity.TOTAL_QUES+ " , "
                    + QuestionEntity.T_QHEAD_NO+ " , "
                    + QuestionEntity.HEADER_NATIVE+ " , "
                    + QuestionEntity.HEADER_ENGLISH+ " "
                    + " ) VALUES (  "
                    + " ?,?,?,?,? "
                    +")";

            stmt = db.compileStatement(sql);
            for(Question obj : list){
                stmt.bindString(1, obj.getHEADER_NO()== null?"":obj.getHEADER_NO());
                stmt.bindString(2, obj.getTOTAL_QUES() == null?"":obj.getTOTAL_QUES());
                stmt.bindString(3, obj.getT_QHEAD_NO() == null?"":obj.getT_QHEAD_NO());
                stmt.bindString(4, obj.getHEADER_NATIVE() == null?"":obj.getHEADER_NATIVE());
                stmt.bindString(5, obj.getHEADER_ENGLISH() == null?"":obj.getHEADER_ENGLISH());
                stmt.execute();
                stmt.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
            Log.i(TAG, "Question Header insert successfully");
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, stmt, null);
            return check;
        }
    }

    public ArrayList<Question> getQHeader() {
        SQLiteDatabase db = null;
        Cursor res = null;
        ArrayList<Question> list = new ArrayList<>();
        try {
            list = new ArrayList<>();
            db = this.getReadableDatabase();
            String query = "SELECT "
                    + QuestionEntity.HEADER_NO + " , " + QuestionEntity.TOTAL_QUES+ " , "
                    + QuestionEntity.T_QHEAD_NO + " , " + QuestionEntity.HEADER_NATIVE+ " , "
                    + QuestionEntity.HEADER_ENGLISH + " "
                    + " FROM " + TABLE_QUESTION_HEADER;

            res = db.rawQuery(query, null);
            res.moveToFirst();
            while (res.isAfterLast() == false) {
                Question obj = new Question();
                obj.setHEADER_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NO)));
                obj.setTOTAL_QUES(res.getString(res.getColumnIndexOrThrow(QuestionEntity.TOTAL_QUES)));
                obj.setT_QHEAD_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QHEAD_NO)));
                obj.setHEADER_NATIVE(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NATIVE)));
                obj.setHEADER_ENGLISH(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_ENGLISH)));
                list.add(obj);
                res.moveToNext();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, res);
            return list;
        }
    }

    public ArrayList<Question> getQuestionsByHeaderNo(String code) {
        SQLiteDatabase db = null;
        Cursor res = null;
        ArrayList<Question> list = new ArrayList<>();
        try {
            db = this.getReadableDatabase();
            String query = "SELECT "
                    + QuestionEntity.HEADER_NO + " , " + QuestionEntity.TOTAL_QUES+ " , "
                    + QuestionEntity.T_QHEAD_NO + " , " + QuestionEntity.HEADER_NATIVE+ " , "
                    + QuestionEntity.HEADER_ENGLISH + "  "
                    + " FROM " + TABLE_QUESTION_HEADER
                    + " WHERE " + QuestionEntity.HEADER_NO + " = '"+ code +"'";

            res = db.rawQuery(query, null);
            res.moveToFirst();
            while (res.isAfterLast() == false) {
                Question obj = new Question();
                obj.setHEADER_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NO)));
                obj.setTOTAL_QUES(res.getString(res.getColumnIndexOrThrow(QuestionEntity.TOTAL_QUES)));
                obj.setT_QHEAD_NO(res.getString(res.getColumnIndexOrThrow(QuestionEntity.T_QHEAD_NO)));
                obj.setHEADER_NATIVE(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_NATIVE)));
                obj.setHEADER_ENGLISH(res.getString(res.getColumnIndexOrThrow(QuestionEntity.HEADER_ENGLISH)));
                list.add(obj);
                res.moveToNext();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, res);
            return list;
        }
    }

    /*public boolean deleteLabelByFormName(String code) {
        SQLiteDatabase db = null;
        boolean check = false;
        try {
            String query = "delete from " + TABLE_LABEL
                    + " WHERE " + LABEL_CODE + " = '"+ code +"'";
            db = this.getWritableDatabase();
            db.execSQL(query);
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, null);
            return check;
        }
    }*/

    public boolean deleteAll() {
        SQLiteDatabase db = null;
        boolean check = false;
        try {
            String query = "delete from " + TABLE_QUESTION_HEADER;
            db = this.getWritableDatabase();
            db.execSQL(query);
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, null);
            return check;
        }
    }
}
