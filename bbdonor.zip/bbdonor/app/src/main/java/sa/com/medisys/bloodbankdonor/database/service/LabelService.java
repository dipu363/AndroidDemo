package sa.com.medisys.bloodbankdonor.database.service;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import sa.com.medisys.bloodbankdonor.api.model.Label;
import sa.com.medisys.bloodbankdonor.database.AppDatabaseSchema;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;

/*
 @author : Md. Abu Bakar Siddique
 @date : 25-OCT-2021
 @version: 1.0.0
*/

public class LabelService extends AppDatabaseSchema {
    private final String TAG = this.getClass().getSimpleName();

    public LabelService(Context context) {
        super(context);
    }

    public boolean insertLabel(List<Label> list) {
        SQLiteDatabase db = null;
        SQLiteStatement stmt = null;
        boolean check = false;
        try {
            db = this.getWritableDatabase();
            db.beginTransactionNonExclusive();

            String sql = "INSERT INTO " + TABLE_LABEL + " ( "
                    + LABEL_CODE + " , " + LABEL_NAME_NATIVE+ " , "
                    + LABEL_NAME_GLOBAL
                    + " ) VALUES (  "
                    + " ?,?,? "
                    +")";

            stmt = db.compileStatement(sql);
            for(Label obj : list){
                stmt.bindString(1, obj.getCODE() == null?"":obj.getCODE());
                stmt.bindString(2, obj.getNAME_NATIVE()== null?"":obj.getNAME_NATIVE());
                stmt.bindString(3, obj.getNAME_GLOBAL() == null?"":obj.getNAME_GLOBAL());
                stmt.execute();
                stmt.clearBindings();
            }
            db.setTransactionSuccessful();
            db.endTransaction();
            Log.i(TAG, "Label insert successfully");
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, stmt, null);
            return check;
        }
    }

    public ArrayList<Label> getLabel() {
        SQLiteDatabase db = null;
        Cursor res = null;
        ArrayList<Label> list = new ArrayList<>();
        try {
            list = new ArrayList<>();
            db = this.getReadableDatabase();
            String query = "SELECT "
                    + LABEL_CODE + " , " + LABEL_NAME_NATIVE+ " , "
                    + LABEL_NAME_GLOBAL
                    + " FROM " + TABLE_LABEL;

            res = db.rawQuery(query, null);
            res.moveToFirst();
            while (res.isAfterLast() == false) {
                Label obj = new Label();
                obj.setCODE(res.getString(res.getColumnIndexOrThrow(LABEL_CODE)));
                obj.setNAME_NATIVE(res.getString(res.getColumnIndexOrThrow(LABEL_NAME_NATIVE)));
                obj.setNAME_GLOBAL(res.getString(res.getColumnIndexOrThrow(LABEL_NAME_GLOBAL)));
                list.add(obj);
                res.moveToNext();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, res);
            return list;
        }
    }

    public ArrayList<Label> getLabelByFormName(String code) {
        SQLiteDatabase db = null;
        Cursor res = null;
        ArrayList<Label> list = new ArrayList<>();
        try {
            db = this.getReadableDatabase();
            String query = "SELECT "
                    + LABEL_CODE + " , " + LABEL_NAME_NATIVE+ " , "
                    + LABEL_NAME_GLOBAL
                    + " FROM " + TABLE_LABEL
                    + " WHERE " + LABEL_CODE + " = '"+ code +"'";

            res = db.rawQuery(query, null);
            res.moveToFirst();
            while (res.isAfterLast() == false) {
                Label obj = new Label();
                obj.setCODE(res.getString(res.getColumnIndexOrThrow(LABEL_CODE)));
                obj.setNAME_NATIVE(res.getString(res.getColumnIndexOrThrow(LABEL_NAME_NATIVE)));
                obj.setNAME_GLOBAL(res.getString(res.getColumnIndexOrThrow(LABEL_NAME_GLOBAL)));
                list.add(obj);
                res.moveToNext();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, res);
            return list;
        }
    }

    public boolean deleteLabelByFormName(String code) {
        SQLiteDatabase db = null;
        boolean check = false;
        try {
            String query = "delete from " + TABLE_LABEL
                    + " WHERE " + LABEL_CODE + " = '"+ code +"'";
            db = this.getWritableDatabase();
            db.execSQL(query);
            check = true;
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            AppUtils.closeDB(db, null, null);
            return check;
        }
    }
}
