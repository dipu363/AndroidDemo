package sa.com.medisys.bloodbankdonor.utils;

import android.content.Context;
import android.util.Log;

import java.util.List;


public class CommonLabel {
    private  final String TAG = this.getClass().getSimpleName();
    Context context;

    public static String  hospitalNameNative;
    public static String  hospitalNameGlobal;
    
    public static String  emptyFieldNative;
    public static String  emptyFieldGlobal;
    
    public static String  noConnectionNative;
    public static String  noConnectionGlobal;
    
    public static String  serverMaintenanceNative;
    public static String  serverMaintenanceGlobal;
    
    public static String  webserviceNotRunningNative;
    public static String  webserviceNotRunningGlobal;
    
    public static String  slowNetworkNative;
    public static String  slowNetworkGlobal;
    
    public static String  errorNative;
    public static String  errorGlobal;
    
    public static String  okNative;
    public static String  okGlobal;
    
    
    public static String  backPressTextNative;
    public static String  backPressTextGlobal;
    
    public static String  logoutConfirmTextNative;
    public static String  logoutConfirmTextGlobal;
    
    public static String  lvNoResultFoundNative;
    public static String  lvNoResultFoundGlobal;
    
    public static String  permissionErrorNative;
    public static String  permissionErrorGlobal;
    
    public static String  dropdownSelectOneNative;
    public static String  dropdownSelectOneGlobal;
    
    public static String  updateConfirmationNative;
    public static String  updateConfirmationGlobal;

    public CommonLabel(Context context) {
        this.context = context;
    }

    /*public void init(){
        List<Label> commonLabels =  new LabelService(context).getLabelByFormName(LabelConstants.commonLabelFormCode);
        Log.i(TAG, "commonLabels"+commonLabels.size());
        for(Label label : commonLabels){
            switch (label.getObjectName()){
                case LabelConstants.commonLabelHospitalName:
                    hospitalNameNative = label.getLabelNative();
                    hospitalNameGlobal = label.getLabelGlobal();
                    break;
                case LabelConstants.commonLabelEmptyField:
                    emptyFieldNative = label.getLabelNative();
                    emptyFieldGlobal = label.getLabelGlobal();
                    break;
                case LabelConstants.commonLabelNoConnection:
                    noConnectionNative = label.getLabelNative();
                    noConnectionGlobal = label.getLabelGlobal();
                    break;
                case LabelConstants.commonLabelServerMaintenance:
                    serverMaintenanceNative = label.getLabelNative();
                    serverMaintenanceGlobal = label.getLabelGlobal();
                    break;
                case LabelConstants.commonLabelWebserviceNotRunning:
                    webserviceNotRunningNative = label.getLabelNative();
                    webserviceNotRunningGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelSlowNetwork:
                    slowNetworkNative = label.getLabelNative();
                    slowNetworkGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelError:
                    errorNative = label.getLabelNative();
                    errorGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelOk:
                    okNative = label.getLabelNative();
                    okGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelBackPressText:
                    backPressTextNative = label.getLabelNative();
                    backPressTextGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelLogoutConfirmText:
                    logoutConfirmTextNative = label.getLabelNative();
                    logoutConfirmTextGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelLvNoResultFound:
                    lvNoResultFoundNative = label.getLabelNative();
                    lvNoResultFoundGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelPermissionError:
                    permissionErrorNative = label.getLabelNative();
                    permissionErrorGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelDropdownSelectOne:
                    dropdownSelectOneNative = label.getLabelNative();
                    dropdownSelectOneGlobal = label.getLabelGlobal();
                    break;
                 case LabelConstants.commonLabelUpdateConfirmation:
                    updateConfirmationNative = label.getLabelNative();
                    updateConfirmationGlobal = label.getLabelGlobal();
                    break;

            }
        }
    }*/
}
