package sa.com.medisys.bloodbankdonor.model;

import java.io.Serializable;

public class PatientInfo implements Serializable {

    private String loginName;
    private String userName;
    private String siteCode;
    private String empCOde;
    private String roleCode;
    private String userLang;
    private String siteNative;
    private String siteGlobal;

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getSiteCode() {
        return siteCode;
    }

    public void setSiteCode(String siteCode) {
        this.siteCode = siteCode;
    }

    public String getEmpCOde() {
        return empCOde;
    }

    public void setEmpCOde(String empCOde) {
        this.empCOde = empCOde;
    }

    public String getRoleCode() {
        return roleCode;
    }

    public void setRoleCode(String roleCode) {
        this.roleCode = roleCode;
    }

    public String getUserLang() {
        return userLang;
    }

    public void setUserLang(String userLang) {
        this.userLang = userLang;
    }

    public String getSiteNative() {
        return siteNative;
    }

    public void setSiteNative(String siteNative) {
        this.siteNative = siteNative;
    }

    public String getSiteGlobal() {
        return siteGlobal;
    }

    public void setSiteGlobal(String siteGlobal) {
        this.siteGlobal = siteGlobal;
    }
}
