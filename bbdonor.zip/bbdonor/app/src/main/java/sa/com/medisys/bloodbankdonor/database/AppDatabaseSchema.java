package sa.com.medisys.bloodbankdonor.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import sa.com.medisys.bloodbankdonor.database.entity.LabelEntity;
import sa.com.medisys.bloodbankdonor.database.entity.QuestionEntity;
import sa.com.medisys.bloodbankdonor.database.entity.QuestionHeaderEntity;


/*
 @author : Md. Abu Bakar Siddique
 @date : 25-OCT-2021
 @version: 1.0.0
*/

public class AppDatabaseSchema extends SQLiteOpenHelper implements
        LabelEntity, QuestionEntity, QuestionHeaderEntity
{

    private static final String DATABASE_NAME = "bloodbankdonor-v100";
    private static final int DATABASE_VERSION = 1;

    public AppDatabaseSchema(Context context) {
        super(context, DATABASE_NAME , null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE_LABEL);
        sqLiteDatabase.execSQL(CREATE_TABLE_QUESTION);
        sqLiteDatabase.execSQL(CREATE_TABLE_QUESTION_HEADER);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_LABEL);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_QUESTION);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+TABLE_QUESTION_HEADER);
        onCreate(sqLiteDatabase);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        db.disableWriteAheadLogging();
    }
}
