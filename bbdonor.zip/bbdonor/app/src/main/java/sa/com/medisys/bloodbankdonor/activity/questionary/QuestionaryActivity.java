package sa.com.medisys.bloodbankdonor.activity.questionary;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import sa.com.medisys.bloodbankdonor.R;
import sa.com.medisys.bloodbankdonor.activity.donor.DonorActivity;
import sa.com.medisys.bloodbankdonor.activity.questionary.adapter.CustomAdapter;
import sa.com.medisys.bloodbankdonor.activity.questionary.ui.main.Fragment_for_question;
import sa.com.medisys.bloodbankdonor.activity.questionary.ui.main.QuestionaryFragment;
import sa.com.medisys.bloodbankdonor.api.DonorWebService;
import sa.com.medisys.bloodbankdonor.api.collection.DonorCollection;
import sa.com.medisys.bloodbankdonor.api.collection.QuestionCollection;
import sa.com.medisys.bloodbankdonor.api.interfaces.DonorApi;
import sa.com.medisys.bloodbankdonor.api.model.Donor;
import sa.com.medisys.bloodbankdonor.api.model.Question;
import sa.com.medisys.bloodbankdonor.database.service.LabelService;
import sa.com.medisys.bloodbankdonor.database.service.QuestionHeaderService;
import sa.com.medisys.bloodbankdonor.database.service.QuestionService;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;
import sa.com.medisys.bloodbankdonor.utils.DonorPreferenceManager;
import sa.com.medisys.bloodbankdonor.utils.MedisysToast;
import sa.com.medisys.bloodbankdonor.utils.alert.ProgressDialog;

public class QuestionaryActivity extends AppCompatActivity implements View.OnClickListener{

    private final String TAG = this.getClass().getSimpleName();
    static Context context;
    private DonorPreferenceManager memory;
    private Dialog dialog;
    private DonorApi api;

    TextView tvDonorId, tvDonorName;
    ListView lvQues;
    Button btnQNext;

    private CustomAdapter mAdapter;

    List<Integer> headerNolist;
    List<Question> qsHeadList = new ArrayList<>();

    QuestionService questionService;
    QuestionHeaderService qHeaderService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.questionary_activity);
        /*if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, QuestionaryFragment.newInstance())
                    .commitNow();
        }*/

        getSupportFragmentManager().beginTransaction().replace(R.id.questionary_containerid, new Fragment_for_question()).commit();

        initialize();
    }

    private void initialize() {
        context = QuestionaryActivity.this;
        memory = new DonorPreferenceManager(context);
        dialog = new ProgressDialog(context, TAG).createDialog();
        api = new DonorWebService().webserviceInitialize();
        mAdapter = new CustomAdapter(this);
        questionService = new QuestionService(context);
        qHeaderService = new QuestionHeaderService(context);

        tvDonorId = findViewById(R.id.tvDonorId);
        tvDonorId.setText(memory.getPref(DonorPreferenceManager.KEY_DONOR_ID));

        tvDonorName = findViewById(R.id.tvDonorName);
        tvDonorName.setText(memory.getPref(DonorPreferenceManager.KEY_USER_NAME));

       /* btnQNext = findViewById(R.id.btnQNext);
        btnQNext.setOnClickListener(this);*/

     //   lvQues = findViewById(R.id.lvQues);

        Log.d(TAG, "DONOR_ID :: " + memory.getPref(DonorPreferenceManager.KEY_DONOR_ID));
        Log.d(TAG, "LANG :: " + memory.getPref(DonorPreferenceManager.KEY_LANG_CODE));
        Log.d(TAG, "GENDER :: " + memory.getPref(DonorPreferenceManager.KEY_GENDER));

        getAllQuestions(memory.getPref(DonorPreferenceManager.KEY_GENDER), memory.getPref(DonorPreferenceManager.KEY_DONOR_ID),
                memory.getPref(DonorPreferenceManager.KEY_LANG_CODE));
    }

    private void getAllQuestions(String gender, String patNo, String lang) {
        dialog.show();
        Call<QuestionCollection> getInfo = api.getQuestionList(gender, patNo, lang);
        getInfo.enqueue(new Callback<QuestionCollection>() {
            @Override
            public void onResponse(Call<QuestionCollection> call, Response<QuestionCollection> response) {
                try{
                    QuestionCollection collection = response.body();
                    Log.d(TAG,"success : " + collection.getSuccess());

                    if(collection.getSuccess().equals("true")){
                        Log.d(TAG, "message : " + collection.getMessage());

                        QuestionService questionService = new QuestionService(context);
                        questionService.deleteAll();

                        questionService.insertQuestion(collection.getData());
                        Log.d(TAG, "insertQuestion : DONE");

                        QuestionHeaderService qHeaderService = new QuestionHeaderService(context);
                        qHeaderService.deleteAll();

                        List<Question> q =  collection.getData();

                        Set<Integer> headerUniqueSet = new HashSet<Integer>();
                        for (int i = 0; i < q.size(); i++) {
                            //Log.d("question", "" + q.get(i).getHEADER_NO() + " :: " + q.get(i).getTOTAL_QUES() + " :: " + q.get(i).getT_QNO());

                            headerUniqueSet.add(Integer.parseInt(q.get(i).getHEADER_NO()));


                        }
                        Log.d("headerlistSize", "" + headerUniqueSet.size());

                        headerNolist = new ArrayList<Integer>(headerUniqueSet);
                        for(int i = 0; i < headerNolist.size(); i++){
                            Question qs = new Question();
                            qs.setHEADER_NO(headerNolist.get(i).toString());
                            qsHeadList.add(qs);
                        }

                        qHeaderService.insertQuestionHeader(qsHeadList);



                        /*hide dialog*/
                        dialog.dismiss();

                    }else {
                        MedisysToast.makeText(context, collection.getMessage(), Toast.LENGTH_SHORT);
                    }
                }catch (Exception e){
                    AppUtils.serverMaintenance(context, e);
                }

                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                /*hide dialog*/
                dialog.dismiss();
            }

            @Override
            public void onFailure(Call<QuestionCollection> call, Throwable t) {
                AppUtils.onApiFailure(context, t, dialog);
            }
        });
    }

    List<Question> qs = new ArrayList<>();

    private void loadListView(String h) {

        qs = questionService.getQuestionsByHeaderNo(h);
        mAdapter.addSectionHeaderItem(new Question(null, null, null, null,
                null, null, null, qs.get(0).getHEADER_ENGLISH(), null,
                null, null, null, null, null, null));

        for (int i = 0; i < qs.size(); i++) {
            mAdapter.addItem(new Question(qs.get(i).getR(), qs.get(i).getHEADER_NO(), qs.get(i).getTOTAL_QUES(),
                    qs.get(i).getQUES_NATIVE(),
                    qs.get(i).getQUES_ENGLISH(), qs.get(i).getT_QHEAD_NO(), qs.get(i).getHEADER_NATIVE(), qs.get(i).getHEADER_ENGLISH(),
                    qs.get(i).getT_QNO(),
                    qs.get(i).getT_DISP_SEQ(), qs.get(i).getT_DIFFERAL_DAY(), qs.get(i).getT_EXP_ANS(), qs.get(i).getT_QNO_ANS(),
                    qs.get(i).getT_QUES_ID(), qs.get(i).getT_IF_FAIL()));
        }

        lvQues.setAdapter(mAdapter);
    }

    int h = 0;
    @Override
    public void onClick(View v) {
        qs.clear();
        mAdapter.notifyDataSetChanged();

        List<Question> qh = qHeaderService.getQHeader();
        Log.d(TAG, "qh.size() :: " + qh.size());

        if(h <= qh.size()){
            loadListView(qh.get(h).getHEADER_NO());
            h++;
        }
    }
}