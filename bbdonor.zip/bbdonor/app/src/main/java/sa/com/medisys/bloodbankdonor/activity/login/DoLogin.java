package sa.com.medisys.bloodbankdonor.activity.login;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import sa.com.medisys.bloodbankdonor.activity.donor.DonorActivity;
import sa.com.medisys.bloodbankdonor.api.DonorWebService;
import sa.com.medisys.bloodbankdonor.api.collection.LoginCollection;
import sa.com.medisys.bloodbankdonor.api.interfaces.DonorApi;
import sa.com.medisys.bloodbankdonor.api.model.Login;
import sa.com.medisys.bloodbankdonor.model.PatientInfo;
import sa.com.medisys.bloodbankdonor.utils.AppConstants;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;
import sa.com.medisys.bloodbankdonor.utils.DonorPreferenceManager;
import sa.com.medisys.bloodbankdonor.utils.MedisysToast;
import sa.com.medisys.bloodbankdonor.utils.alert.ProgressDialog;

/*
 @author : Md. Abu Bakar Siddique
 @date : 20-AUG-2019
 @version: 1.0.0
*/
public class DoLogin implements AppConstants {

    private final String TAG = this.getClass().getSimpleName();
    static  Context context;
    DonorApi api;
    private Dialog dialog;
    private DonorPreferenceManager memory;

    public DoLogin(Context context) {
        this.context = context;
        this.api = new DonorWebService().webserviceInitialize();
        this.dialog = new ProgressDialog(context, TAG).createDialog();
        this.memory = new DonorPreferenceManager(context);
    }

    public void login(final String userId, final String password) {
        /*show dialog*/
        dialog.show();
        Call<LoginCollection> getInfo = api.login(userId, password);
        getInfo.enqueue(new Callback<LoginCollection>() {
            @Override
            public void onResponse(Call<LoginCollection> call, Response<LoginCollection> response) {
                try{
                    LoginCollection collection = response.body();
                    Log.d(TAG,"success : " + collection.getSuccess());

                    if(collection.getSuccess().equals("true")){
                        Log.d(TAG, "message : " + collection.getMessage());

                        Login login =  collection.getData();
                        Log.d(TAG, "NAME : " + login.getT_LOGIN_NAME());

                        PatientInfo patInfo = new PatientInfo();
                        patInfo.setLoginName(login.getT_LOGIN_NAME());
                        patInfo.setUserName(login.getT_USER_NAME());
                        patInfo.setSiteCode(login.getT_SITE_CODE());
                        patInfo.setEmpCOde(login.getT_EMP_CODE());
                        patInfo.setRoleCode(login.getT_ROLE_CODE());
                        patInfo.setUserLang(login.getT_USER_LANG());
                        patInfo.setSiteNative(login.getSITE_NATIVE());
                        patInfo.setSiteGlobal(login.getSITE_GLOBAL());

                        memory.putPref(DonorPreferenceManager.KEY_LANG_CODE, patInfo.getUserLang());
                        memory.putPref(DonorPreferenceManager.KEY_TO_SITE_CODE, patInfo.getSiteCode());
                        memory.putPref(DonorPreferenceManager.KEY_USER_NAME, patInfo.getUserName());

                        /*hide dialog*/
                        dialog.dismiss();

                        gotToNextActivity();
                    }else {
                        MedisysToast.makeText(context, collection.getMessage(), Toast.LENGTH_SHORT);
                    }
                }catch (Exception e){
                    AppUtils.serverMaintenance(context, e);
                }

                /*hide dialog*/
                dialog.dismiss();
            }

            @Override
            public void onFailure(Call<LoginCollection> call, Throwable t) {
                AppUtils.onApiFailure(context, t, dialog);
            }
        });
    }

    public static void gotToNextActivity(){
        Intent intent = new Intent(context, DonorActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
        ((Activity) context).finish();
    }





}
