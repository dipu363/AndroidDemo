package sa.com.medisys.bloodbankdonor.utils;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import sa.com.medisys.bloodbankdonor.R;


/*
 @author : Md. Abu Bakar Siddique
 @date : 02-JUN-2019
 @version: 1.0.1
*/

public class MedisysToast {

    public static void makeText(Context context, String message, int length) {
        View view = LayoutInflater.from(context).inflate(R.layout.custom_toast, null);
        TextView textView1 =  view.findViewById(R.id.textView1);

        Toast toast = new Toast(context);
        textView1.setText(message);
        toast.setView(view);
        toast.setDuration(length);
        toast.show();
    }

}
