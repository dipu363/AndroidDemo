package sa.com.medisys.bloodbankdonor.utils;

import android.content.Context;
import android.content.SharedPreferences;

/*
 @author : Md. Abu Bakar Siddique
 @date : 02-JUN-2019
 @version: 1.0.1
*/

public class DonorPreferenceManager {
	
    private static final String TAG = "PreferenceManager"; 
    int PRIVATE_MODE = 0;
    private static final String PREF_NAME = "patAffairsPrefs";

    /*properties*/
	public static final String KEY_USER_NAME = "userName";
	public static final String KEY_LANG_CODE = "langCode";
	public static final String KEY_TO_SITE_CODE = "siteCode";
	public static final String KEY_DONOR_ID = "donorId";
	public static final String KEY_GENDER = "gender";
	public static final String KEY_LANG = "lang";

	 private SharedPreferences prefs;
	 private Context mContext;

	public DonorPreferenceManager(Context aContext){
		this. mContext = aContext;
	    prefs = aContext.getSharedPreferences(PREF_NAME,  PRIVATE_MODE);
	  
	}
	
	public  void putPref(String key, String value) {
		SharedPreferences.Editor editor = prefs.edit();
		editor.putString(key, value);
		editor.commit();
	}

	public  String getPref(String key) {
		return prefs.getString(key, null);
	}
	
	/**
	 *  Method used to delete Preferences */
	public void deletePreferences(String key) {
		SharedPreferences.Editor editor = prefs.edit();
	    editor.remove(key).commit();
	}

	public void clearPreferences() {
		SharedPreferences.Editor editor = prefs.edit();
		editor.clear().commit();
	}

}
