package sa.com.medisys.bloodbankdonor.utils.alert;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.util.Log;
import android.view.Window;
import android.widget.ImageView;

import sa.com.medisys.bloodbankdonor.R;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;

/*
 @author : Md. Abu Bakar Siddique
 @date : 02-JUN-2019
 @version: 1.0.1
*/
public class ProgressDialog {

    private Context context;
    private String TAG;

    public ProgressDialog(Context context, String TAG) {
        this.context = context;
        this.TAG = TAG;
    }

    public Dialog createDialog(){
        Dialog dialog = new Dialog(context, android.R.style.Theme_Dialog);
        dialog.setCancelable(false);
        ImageView imageView = new ImageView(context);
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        imageView.setBackgroundResource(R.drawable.progress_dialog_animation);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(imageView);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        AnimationDrawable animationDrawable = (AnimationDrawable) imageView.getBackground();
        animationDrawable.start();
        return dialog;
    }

    public void show(Dialog dialog) {
        if(!AppUtils.isNullObject(dialog)){
            Log.i(TAG, "Loader show .........");
            dialog.show();
        }
    }

    public void hide(Dialog dialog){
        if(!AppUtils.isNullObject(dialog)){
            Log.i(TAG, "Loader hide .........");
            dialog.dismiss();
        }
    }
}
