package sa.com.medisys.bloodbankdonor.utils.alert;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.widget.ImageButton;
import android.widget.TextView;

import sa.com.medisys.bloodbankdonor.R;

/*
 @author : Md. Abu Bakar Siddique
 @date : 25-OCT-2021
 @version: 1.0.0
*/
public class ConfirmDialog {

    private Context context;
    private Dialog dialog;

    public ImageButton btnCancel;
    public ImageButton btnConfirmation;
    TextView txtHeader;

    public ConfirmDialog(Context context) {
        this.context = context;
        build();
    }

    public void build() {
        dialog = new Dialog(context);
        dialog.setContentView(R.layout.alert_update_confirmation);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        btnCancel = dialog.findViewById(R.id.btnCancel);
        btnConfirmation = dialog.findViewById(R.id.btnConfirmation);
        txtHeader = dialog.findViewById(R.id.txtHeader);
    }

    public void show(String message) {
        txtHeader.setText(message);
        dialog.show();
    }

    public void dismiss(){
        dialog.dismiss();
    }
}
