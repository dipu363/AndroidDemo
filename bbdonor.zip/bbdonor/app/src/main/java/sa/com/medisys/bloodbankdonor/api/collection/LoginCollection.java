package sa.com.medisys.bloodbankdonor.api.collection;

/*
 @author : Md. Abu Bakar Siddique
 @date : 20-AUG-2019
 @version: 1.0.0
*/


import sa.com.medisys.bloodbankdonor.api.model.Login;

public class LoginCollection {

    private Login data;
    private String success;
    private String message;
    private String message_native;

    public Login getData() {
        return data;
    }

    public void setData(Login data) {
        this.data = data;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getMessage_native() {
        return message_native;
    }

    public void setMessage_native(String message_native) {
        this.message_native = message_native;
    }
}
