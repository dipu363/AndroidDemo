package sa.com.medisys.bloodbankdonor.utils.alert;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import sa.com.medisys.bloodbankdonor.R;

/*
 @author : Md. Abu Bakar Siddique
 @date : 02-JUN-2019
 @version: 1.0.1
*/
public class MedisysAlertDialog {

    private Context context;

    public MedisysAlertDialog(Context context) {
        this.context = context;
    }

    public void show(String headerText, String message) {
        final AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        View view = LayoutInflater.from(context).inflate(R.layout.alert_dialog, null);

        TextView txtHeader =  view.findViewById(R.id.txtHeader);
        TextView txtMessage =  view.findViewById(R.id.txtMessage);
        Button btnOk =  view.findViewById(R.id.btnOk);

        txtHeader.setText(headerText);
        txtMessage.setText(message);
        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.dismiss();
            }
        });

        /*Showing Alert Message*/
        alertDialog.setView(view);
        alertDialog.setCancelable(false);
        alertDialog.show();
    }
}
