package sa.com.medisys.bloodbankdonor.activity.donor;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import sa.com.medisys.bloodbankdonor.R;
import sa.com.medisys.bloodbankdonor.activity.login.MainActivity;
import sa.com.medisys.bloodbankdonor.activity.questionary.QuestionaryActivity;
import sa.com.medisys.bloodbankdonor.api.DonorWebService;
import sa.com.medisys.bloodbankdonor.api.collection.DonorCollection;
import sa.com.medisys.bloodbankdonor.api.collection.LoginCollection;
import sa.com.medisys.bloodbankdonor.api.interfaces.DonorApi;
import sa.com.medisys.bloodbankdonor.api.model.Donor;
import sa.com.medisys.bloodbankdonor.api.model.Login;
import sa.com.medisys.bloodbankdonor.model.PatientInfo;
import sa.com.medisys.bloodbankdonor.utils.AppConstants;
import sa.com.medisys.bloodbankdonor.utils.AppUtils;
import sa.com.medisys.bloodbankdonor.utils.DonorPreferenceManager;
import sa.com.medisys.bloodbankdonor.utils.MedisysToast;
import sa.com.medisys.bloodbankdonor.utils.alert.ProgressDialog;

public class DonorActivity extends AppCompatActivity implements AppConstants, View.OnClickListener {

    private final String TAG = this.getClass().getSimpleName();
    static  Context context;
    private DonorPreferenceManager memory;
    private DonorApi api;
    private Dialog dialog;

    EditText edtDonnerId;
    TextView lblDonorNameEn, lblDonorNameAr;
    Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_info);
        getSupportActionBar().setTitle("Donor Information");

        initialize();
    }

    private void initialize() {
        context = DonorActivity.this;
        api = new DonorWebService().webserviceInitialize();
        dialog = new ProgressDialog(context, TAG).createDialog();
        memory = new DonorPreferenceManager(context);

        edtDonnerId = findViewById(R.id.edtDonnerId);
        lblDonorNameEn = findViewById(R.id.lblDonorNameEn);
        lblDonorNameAr = findViewById(R.id.lblDonorNameAr);
        btnNext = findViewById(R.id.btnNext);
        btnNext.setOnClickListener(this);

        Log.d(TAG, "SITE_CODE:: " + memory.getPref(SITE_CODE));

        edtDonnerId.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                int length = s.length();
                if(length == 8){
                    String donerid = edtDonnerId.getText().toString().trim();
                    Log.d(TAG, "SITE CODE:: " + memory.getPref(SITE_CODE));
                    getDonnerInfo(donerid, memory.getPref(SITE_CODE));
                }
            }
        });

    }

    @Override
    public void onClick(View v) {

    }

    private void getDonnerInfo(String donerid, String siteCOde) {
        dialog.show();
        Call<DonorCollection> getInfo = api.getDonorInfo(donerid, siteCOde);
        getInfo.enqueue(new Callback<DonorCollection>() {
            @Override
            public void onResponse(Call<DonorCollection> call, Response<DonorCollection> response) {
                try{
                    DonorCollection collection = response.body();
                    Log.d(TAG,"success : " + collection.getSuccess());

                    if(collection.getSuccess().equals("true")){
                        Log.d(TAG, "message : " + collection.getMessage());

                        Donor donor =  collection.getData();
                        Log.d(TAG, "NAME : " + donor.getNAME_ENGLISH());

                        memory.putPref(DonorPreferenceManager.KEY_DONOR_ID, donor.getT_PAT_NO());
                        memory.putPref(DonorPreferenceManager.KEY_GENDER, donor.getT_GENDER());

                        /*hide dialog*/
                        dialog.dismiss();

                        gotToNextActivity();
                    }else {
                        MedisysToast.makeText(context, collection.getMessage(), Toast.LENGTH_SHORT);
                    }
                }catch (Exception e){
                    AppUtils.serverMaintenance(context, e);
                }

                /*hide dialog*/
                dialog.dismiss();
            }

            @Override
            public void onFailure(Call<DonorCollection> call, Throwable t) {
                AppUtils.onApiFailure(context, t, dialog);
            }
        });
    }

    public static void gotToNextActivity(){
        Intent intent = new Intent(context, QuestionaryActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(intent);
        ((Activity) context).finish();
    }
}