package sa.com.medisys.bloodbankdonor.database.entity;

/*
 @author : Md. Abu Bakar Siddique
 @date : 27-OCT-2021
 @version: 1.0.0
*/

public interface QuestionEntity {

    /*==================== LABEL ====================*/
    //QUESTION
    String TABLE_QUESTION = "QUESTION";

    // QUESTION TABLE COLUMN NAME
    String MROW = "MROW";
    String HEADER_NO = "HEADER_NO";
    String TOTAL_QUES = "TOTAL_QUES";
    String QUES_NATIVE = "QUES_NATIVE";
    String QUES_ENGLISH = "QUES_ENGLISH";
    String T_QHEAD_NO = "T_QHEAD_NO";
    String HEADER_NATIVE = "HEADER_NATIVE";
    String HEADER_ENGLISH = "HEADER_ENGLISH";
    String T_QNO = "T_QNO";
    String T_DISP_SEQ = "T_DISP_SEQ";
    String T_DIFFERAL_DAY = "T_DIFFERAL_DAY";
    String T_EXP_ANS = "T_EXP_ANS";
    String T_QNO_ANS = "T_QNO_ANS";
    String T_QUES_ID = "T_QUES_ID";
    String T_IF_FAIL = "T_IF_FAIL";


    /*QUESTION table create*/
    String CREATE_TABLE_QUESTION = "CREATE TABLE "
            + TABLE_QUESTION + "("
            + MROW + " TEXT ," + HEADER_NO+ " TEXT ,"
            + TOTAL_QUES + " TEXT ," + QUES_NATIVE+ " TEXT ,"
            + QUES_ENGLISH + " TEXT ," + T_QHEAD_NO+ " TEXT ,"
            + HEADER_NATIVE + " TEXT ," + HEADER_ENGLISH+ " TEXT ,"
            + T_QNO + " TEXT ," + T_DISP_SEQ+ " TEXT ,"
            + T_DIFFERAL_DAY + " TEXT ," + T_EXP_ANS+ " TEXT ,"
            + T_QNO_ANS + " TEXT ," + T_QUES_ID+ " TEXT ,"
            + T_IF_FAIL + " TEXT " + ")";
}
