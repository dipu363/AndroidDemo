package sa.com.medisys.bloodbankdonor.utils;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;


import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import okhttp3.ResponseBody;
import sa.com.medisys.bloodbankdonor.R;
import sa.com.medisys.bloodbankdonor.utils.alert.MedisysAlertDialog;

/*
 @author : Md. Abu Bakar Siddique
 @date : 02-JUN-2019
 @version: 1.0.1
*/

public class AppUtils {

    /***************** << LANG >> *****************/
    public static boolean isNativeActive(Context context) {
        DonorPreferenceManager memory = new DonorPreferenceManager(context);
        String langCode = memory.getPref(DonorPreferenceManager.KEY_LANG_CODE);
        if(!TextUtils.isEmpty(langCode) && langCode.equals("2")){
            return true;
        }
        return false;
    }

    /***************** << API >> *****************/
    public static boolean isConnected(Context context) {
        ConnectivityManager connMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnected());
    }

    public static  void noNetworkConnection(Context context){
        new MedisysAlertDialog(context).show(context.getResources().getString(R.string.common_error),context.getResources().getString(R.string.common_no_connection));
    }

    public static  void serverMaintenance(Context context, Exception e){
        e.printStackTrace();
        new MedisysAlertDialog(context).show(context.getResources().getString(R.string.common_error),context.getResources().getString(R.string.common_server_maintenance));
    }

    public static  void onApiFailure(Context context, Throwable t, Dialog dialog){
        /*hide dialog*/
        if(!AppUtils.isNullObject(dialog)){
            dialog.dismiss();
        }
        t.printStackTrace();
        new MedisysAlertDialog(context).show(context.getResources().getString(R.string.common_error),context.getResources().getString(R.string.common_webservice_not_running));
    }

    public static  void slowNetwork(Context context){
        MedisysToast.makeText(context, context.getResources().getString(R.string.common_slow_network), Toast.LENGTH_SHORT);
    }

    /***************** << ACTIVITY BUTTON >> *****************/
    public static void backToPrevious(Context context, Activity activity){
        Intent previousActivityIntent = new Intent(context, activity.getClass());
        previousActivityIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(previousActivityIntent);
        ((Activity) context).finish();
    }

    /*public static void logout(final Context context, final DonorPreferenceManager memory){
        *//*confirm dialog*//*
        final ConfirmDialog confirmDialog = new ConfirmDialog(context);
        confirmDialog.btnConfirmation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog.dismiss();
                memory.clearPreferences();
                new PrescriptionService(context).deleteAllPrescription();
                Intent intent = new Intent(context, LoginActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(intent);
                ((Activity)context).finish();
            }
        });

        confirmDialog.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confirmDialog.dismiss();
            }
        });

        String logoutText = AppUtils.isNativeActive(context)? CommonLabel.logoutConfirmTextNative :  CommonLabel.logoutConfirmTextGlobal;

        confirmDialog.show(logoutText);
        *//*confirm dialog*//*

    }*/

    /***************** << DB >> *****************/
    public static void closeDB(SQLiteDatabase db, SQLiteStatement stmt, Cursor res){
        if(db != null){
            db.close();
        }
        if(stmt != null){
            stmt.close();
        }
        if(res != null){
            res.close();
        }
    }

    /***************** << DATE >> *****************/
    public static String getFormattedServiceDate(String serviceDate){
        //1996-09-16T00:00:00
        try{
            DateFormat serviceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
            return new SimpleDateFormat("dd-MMM-yyyy").format(serviceDateFormat.parse(serviceDate));
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getFormattedServiceDate2(String serviceDate){
        //1996-09-16T00:00:00
        try{
            DateFormat serviceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
            return new SimpleDateFormat("dd-MM-yyyy").format(serviceDateFormat.parse(serviceDate));
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getFormattedServiceDateWithoutTime(String serviceDate){
        //1996-09-16T00:00:00
        try{
            DateFormat serviceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
            return new SimpleDateFormat("yyyy-MM-dd").format(serviceDateFormat.parse(serviceDate));
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getFormattedServiceDateWithoutT(String serviceDate){
        //1996-09-16T00:00:00
        try{
            DateFormat serviceDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            return new SimpleDateFormat("dd-MMM-yyyy").format(serviceDateFormat.parse(serviceDate));
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String addDayWithDate(String serviceDate, String numberOfDay){
        //2018-04-15
        try{
            DateFormat serviceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
            Calendar oldDate = Calendar.getInstance();
            oldDate.setTime(serviceDateFormat.parse(serviceDate));
            oldDate.add(Calendar.DAY_OF_MONTH, Integer.parseInt(numberOfDay)-1);
            return new SimpleDateFormat("dd-MMM-yyyy").format(oldDate.getTime());
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String convertStringDateToJsonDate(String date) {
        try{
            DateFormat serviceDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(serviceDateFormat.parse(date));
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getFormattedServiceDateWithDayName(String serviceDate){
        //1996-09-16T00:00:00
        try{
            DateFormat serviceDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
            return new SimpleDateFormat("EEEE dd MMM").format(serviceDateFormat.parse(serviceDate));
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getFormattedServiceTime(String time){
        if (time != null && time.length() > 3) {
            return  time.substring(0, 2) + ":" + time.substring(2);
        } else if (time != null && time.length() == 2) {
            return  "0"+time.substring(0, 1) + ":0" + time.substring(1);
        } else {
            return "0"+time.substring(0, 1) + ":" + time.substring(1);
        }
    }

    public static String getTime12HourFormat(String time){
        try{
            return new SimpleDateFormat("hh:mm a").format(new SimpleDateFormat("HH:mm").parse(getFormattedServiceTime(time)));
        }catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    public static String getCurrentDate(){
        try{
            return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getCurrentDateWithMonthName(){
        try{
            return new SimpleDateFormat("dd-MMM-yyyy").format(new Date());
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getCurrentDateWithDayName(){
        try{
            return new SimpleDateFormat("EEE, MMM d, yyyy").format(new Date());
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getJsonDate(String stringDate){
        try{
            Date utilDate = new SimpleDateFormat("EEE, MMM d, yyyy").parse(stringDate);
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(utilDate);
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getCurrentJsonDate(){
        try{
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(new Date());
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getCurrentJsonTime(){
        try{
            return new SimpleDateFormat("HHmm").format(new Date());
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String getDateFromCalenderSelectionDate(String stringDate){
        try{
            Date utilDate = new SimpleDateFormat("EEE, MMM d, yyyy").parse(stringDate);
            return new SimpleDateFormat("yyyy-MM-dd").format(utilDate);
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean isAppTimePassed(String stringDate, String stringTime){
        //2019-09-01T00:00:00
        try{
            Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss").parse(stringDate);
            if(DateUtils.isToday(date.getTime())){
                Calendar currentTime = Calendar.getInstance();
                currentTime.add(Calendar.MINUTE, 30);
                Calendar serviceTime = Calendar.getInstance();
                serviceTime.setTime(new SimpleDateFormat("yyyy-MM-ddHH:mm").parse(new SimpleDateFormat("yyyy-MM-dd").format(date)+AppUtils.getFormattedServiceTime(stringTime)));
//                Log.i("TAG", "current time : "+new SimpleDateFormat("yyyy-MM-dd HH:mm").format(currentTime.getTime()));
//                Log.i("TAG", "serviceTime time : "+new SimpleDateFormat("yyyy-MM-dd HH:mm").format(serviceTime.getTime()));
                if (serviceTime.getTime().before(currentTime.getTime())) {
                    return true;
                }
            }
            return false;
        }catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean isDateBetweenTwoDate(String fromDate, String toDate, String dateToCompare){
        try {
            Date minDate = new SimpleDateFormat("dd-MMM-yyyy").parse(fromDate);
            Date maxDate = new SimpleDateFormat("dd-MMM-yyyy").parse(toDate);
            Date compareDate = new SimpleDateFormat("dd-MMM-yyyy").parse(dateToCompare);

            if(compareDate.after(minDate) && compareDate.before(maxDate)){
                return true;
            }else {
                return false;
            }

        }catch (ParseException e){
            e.printStackTrace();
            return false;
        }
    }

    /*public static boolean ageCalculator(String dob){

        LocalDate birthdate = new LocalDate (1970, 1, 20);      //Birth date
        LocalDate now = new LocalDate();                        //Today's date

        Period period = new Period(birthdate, now, PeriodType.yearMonthDay());

        //Now access the values as below
        System.out.println(period.getDays());
        System.out.println(period.getMonths());
        System.out.println(period.getYears());
    }*/



    /***************** << MAP >> *****************/
    public class LocationConstants {
        public static final int SUCCESS_RESULT = 0;

        public static final int FAILURE_RESULT = 1;

        public static final String PACKAGE_NAME = "com.sample.sishin.maplocation";

        public static final String RECEIVER = PACKAGE_NAME + ".RECEIVER";

        public static final String RESULT_DATA_KEY = PACKAGE_NAME + ".RESULT_DATA_KEY";

        public static final String LOCATION_DATA_EXTRA = PACKAGE_NAME + ".LOCATION_DATA_EXTRA";

        public static final String LOCATION_DATA_AREA = PACKAGE_NAME + ".LOCATION_DATA_AREA";
        public static final String LOCATION_DATA_CITY = PACKAGE_NAME + ".LOCATION_DATA_CITY";
        public static final String LOCATION_DATA_STREET = PACKAGE_NAME + ".LOCATION_DATA_STREET";


    }

    public static boolean isLocationEnabled(Context context) {
        int locationMode = 0;
        String locationProviders;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            try {
                locationMode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);

            } catch (Settings.SettingNotFoundException e) {
                e.printStackTrace();
            }
            return locationMode != Settings.Secure.LOCATION_MODE_OFF;
        } else {
            locationProviders = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
            return !TextUtils.isEmpty(locationProviders);
        }
    }

    /***************** << OTHER >> *****************/
    public static boolean isNullObject(Object obj){
        return obj == null ? true : false;
    }

    /*public static void openDatePicker(final Context context, View view, final TextView tvEng, final TextView tvAr) {
        final Calendar c = Calendar.getInstance();
        final int mYear = c.get(Calendar.YEAR);
        final int mMonth = c.get(Calendar.MONTH);
        final int mDay = c.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(view.getContext(), AlertDialog.THEME_HOLO_LIGHT,
                new DatePickerDialog.OnDateSetListener(){
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.set(year, monthOfYear, dayOfMonth);
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
                        String dateString = dateFormat.format(calendar.getTime());
                        tvEng.setText(dateString.toUpperCase());

                        if(tvAr != null){
                            SimpleDateFormat dateFormatArabic = new SimpleDateFormat("dd-MM-yyyy");
                            String dateEnglish = dateFormatArabic.format(calendar.getTime());
                            String d = MedisysDateUtils.convertGregorianToHijriDate(context, MedisysDateUtils.ConvertToDate(dateEnglish, "dd-MM-yyyy", "dd-MM-yyyy"), "-");
                            Log.d("CAL-DATE", "HIJRI DATE :: " + d);
                            String arDate = MedisysDateUtils.convertToArabicDate(d, "-");
                            tvAr.setText(arDate);
                        }

                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.show();
    }*/

    /*public static void openHijriDatePicker(Context context, final TextView tv){
        UmmalquraCalendar now = new UmmalquraCalendar();
        HijriDatePickerDialog dpd = HijriDatePickerDialog.newInstance(
                new HijriDatePickerDialog.OnDateSetListener(){
                    @Override
                    public void onDateSet(HijriDatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
                        String day = String.valueOf(dayOfMonth).length() < 2 ? "0"+dayOfMonth : dayOfMonth+"";
                        int actualMonth = monthOfYear+1;
                        String month = String.valueOf(actualMonth).length() < 2 ? "0"+actualMonth : actualMonth+"";
                        tv.setText(day+"/"+month+"/"+year);
                    }
                },
                now.get(UmmalquraCalendar.YEAR),
                now.get(UmmalquraCalendar.MONTH),
                now.get(UmmalquraCalendar.DAY_OF_MONTH));
        dpd.show(((Activity)context).getFragmentManager(), "HijriDatePickerDialog");
    }*/

    public static void openTimePicker(final Context context, final TextView tv){
        Calendar mcurrentTime = Calendar.getInstance();
        int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
        int minute = mcurrentTime.get(Calendar.MINUTE);
        TimePickerDialog mTimePicker;
        mTimePicker = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                String hour = selectedHour <10 ? "0"+selectedHour : selectedHour+"";
                String minute = selectedMinute <10 ? "0"+selectedMinute : selectedMinute+"";
                tv.setText(hour + ":" + minute);
            }
        }, hour, minute, true);//Yes 24 hour time
        //mTimePicker.setTitle("Select Time");
        mTimePicker.show();
    }

    public static boolean isUserLogin(Context context){
        if(AppUtils.isNullObject(new DonorPreferenceManager(context).getPref(DonorPreferenceManager.KEY_USER_NAME))){
            return false;
        }else {
            return true;
        }
    }

    public void getPdfFile(final Context context, ResponseBody body, final String fileName, final String location, boolean isNeedDialog) {
        try {
            /*file location for save*/
            String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/PATAFFAIRS/report/" + location;
            File dir = new File(path);
            if(!dir.exists())
                dir.mkdirs();
            File file = new File(dir, fileName+".pdf");
            /* // file location for save*/

            InputStream inputStream = null;
            OutputStream outputStream = null;
            try {
                byte[] fileReader = new byte[4096];
                long fileSize = body.contentLength();
                long fileSizeDownloaded = 0;
                inputStream = body.byteStream();
                outputStream = new FileOutputStream(file);

                while (true) {
                    int read = inputStream.read(fileReader);
                    if (read == -1) {
                        break;
                    }
                    outputStream.write(fileReader, 0, read);
                    fileSizeDownloaded += read;
                }
                outputStream.flush();

                Log.i("TAG", "pdf create complete");

                if(isNeedDialog){
                    String fileLocation = "PATAFFAIRS" + File.separator + "report" + File.separator + location + File.separator + fileName + ".pdf";
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setMessage("Download File Location : "+fileLocation)
                            .setPositiveButton("Preview", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog,int id) {
                                    dialog.cancel();
                                    openPdf(context, fileName, location);
                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog,int id) {
                                    dialog.cancel();
                                }
                            })
                            .setCancelable(false)
                            .show();

                }else {
                    openPdf(context, fileName, location);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }

                if (outputStream != null) {
                    outputStream.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void openPdf(Context context, String fileName, String location) {
        String path = "PATAFFAIRS" + File.separator + "report" + File.separator + location + File.separator + fileName + ".pdf";
        Log.i("filePath ", path);
        File file = new File(Environment.getExternalStorageDirectory()+ File.separator + path);
        // Uri uri = Uri.fromFile(file);
        Uri uri = FileProvider.getUriForFile(context,
                context.getApplicationContext()
                        .getPackageName() + ".provider", file);
        Log.i("uri", uri.toString());

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            // set flag to give temporary permission to external app to use your FileProvider
            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(uri, "application/pdf");
            // validate that the device can open your File!
            PackageManager pm = context.getPackageManager();
            if (intent.resolveActivity(pm) != null) {
                context.startActivity(intent);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("ERROR", "No PDF Viewer is found.!!!");
            MedisysToast.makeText(context,"No PDF Viewer is found.", Toast.LENGTH_LONG);
        }
    }

    public static void setUnderLineText(TextView tv, String textToUnderLine) {
        String tvt = tv.getText().toString();
        int ofe = tvt.indexOf(textToUnderLine, 0);

        UnderlineSpan underlineSpan = new UnderlineSpan();
        SpannableString wordToSpan = new SpannableString(tv.getText());
        for (int ofs = 0; ofs < tvt.length() && ofe != -1; ofs = ofe + 1) {
            ofe = tvt.indexOf(textToUnderLine, ofs);
            if (ofe == -1)
                break;
            else {
                wordToSpan.setSpan(underlineSpan, ofe, ofe + textToUnderLine.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                tv.setText(wordToSpan, TextView.BufferType.SPANNABLE);
            }
        }
    }

    public void getOnlyPdfFile(Context context, ResponseBody body, String fileName, String location) {
        try {
            /*file location for save*/
            String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/PATAFFAIRS/report/" + location;
            File dir = new File(path);
            if(!dir.exists())
                dir.mkdirs();
            File file = new File(dir, fileName+".pdf");
            /* // file location for save*/

            InputStream inputStream = null;
            OutputStream outputStream = null;
            try {
                byte[] fileReader = new byte[4096];
                long fileSize = body.contentLength();
                long fileSizeDownloaded = 0;
                inputStream = body.byteStream();
                outputStream = new FileOutputStream(file);

                while (true) {
                    int read = inputStream.read(fileReader);
                    if (read == -1) {
                        break;
                    }
                    outputStream.write(fileReader, 0, read);
                    fileSizeDownloaded += read;
                }
                outputStream.flush();

                Log.i("TAG", "pdf create complete");
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                if (inputStream != null) {
                    inputStream.close();
                }

                if (outputStream != null) {
                    outputStream.close();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean isFileExist(String location, String fileName) {
        String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/PATAFFAIRS/report/" + location + File.separator + fileName + ".pdf";
        File file = new File(path);
        if(!file.exists()){
            return false;
        }
        return true;
    }

}
