package sa.com.medisys.bloodbankdonor.database.entity;

/*
 @author : Md. Abu Bakar Siddique
 @date : 25-OCT-2021
 @version: 1.0.0
*/

public interface LabelEntity {

    /*==================== LABEL ====================*/
    //LABEL
    String TABLE_LABEL = "LABEL";

    // LABEL TABLE COLUMN NAME
    String LABEL_CODE = "CODE";
    String LABEL_NAME_NATIVE = "NAME_NATIVE";
    String LABEL_NAME_GLOBAL = "NAME_GLOBAL";


    /*LABEL table create*/
    String CREATE_TABLE_LABEL = "CREATE TABLE "
            + TABLE_LABEL + "("
            + LABEL_CODE + " TEXT ," + LABEL_NAME_NATIVE+ " TEXT ,"
            + LABEL_NAME_GLOBAL + " TEXT " + ")";
}
